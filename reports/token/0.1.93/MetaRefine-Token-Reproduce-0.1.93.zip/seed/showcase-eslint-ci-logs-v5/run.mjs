import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const components = ["orders", "billing", "inventory", "shipping", "accounts", "reporting"];
const component = process.argv[3];
if (process.argv[2] !== "lint" || !components.includes(component)) {
  console.error("usage: npm run lint -- <component>");
  process.exit(2);
}
const sourceRoot = path.join("src", component);
mkdirSync(sourceRoot, { recursive: true });
for (let i = 0; i < 6; i += 1) {
  const n = String(i).padStart(3, "0");
  const source = "export function check" + n + "(value) {\n  const result = value + " + i + ";\n  return result;\n}\n";
  writeFileSync(path.join(sourceRoot, "module-" + n + ".js"), source);
}
function runTool(name, args) {
  const command = `"${[name + ".cmd", ...args].join(" ")} 2>&1"`;
  return spawnSync(process.env.ComSpec || "cmd.exe", ["/d", "/s", "/c", command], {
    encoding: "utf8",
    maxBuffer: 1024 * 1024,
    windowsVerbatimArguments: true
  });
}
const result = runTool("eslint", [sourceRoot.replaceAll("\\", "/"), "--format", "stylish", "--debug"]);
const exitCode = result.status ?? 1;
if (result.stdout) process.stdout.write(result.stdout);
if (result.stderr) process.stderr.write(result.stderr);
process.exitCode = exitCode;
