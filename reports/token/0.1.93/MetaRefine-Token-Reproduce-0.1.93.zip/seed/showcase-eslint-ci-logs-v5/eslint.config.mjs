export default [{
  files: ["src/**/*.js"],
  languageOptions: { ecmaVersion: "latest", sourceType: "module" },
  rules: { "no-unused-vars": ["error", { vars: "all", args: "none" }] }
}];