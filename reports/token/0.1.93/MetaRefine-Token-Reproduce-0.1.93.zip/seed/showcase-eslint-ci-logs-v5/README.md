# ESLint CI inline log workspace

This variant generates six deterministic JavaScript modules for the selected component. It invokes the native ESLint CLI with its `stylish` formatter and debug logging, then uses Windows `cmd.exe` `2>&1` to forward the original combined stdout/stderr and actual exit status. It is intended to keep CI combined logs within the WorkBuddy Harness inline preview limit; confirm the actual captured output in the prepared environment. Generated files stay inside the copied workspace.
