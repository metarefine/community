import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const components = ["orders", "billing", "inventory", "shipping", "accounts", "reporting"];
const component = process.argv[3];
if (process.argv[2] !== "build" || !components.includes(component)) {
  console.error("usage: npm run build -- <component>");
  process.exit(2);
}
const sourceRoot = path.join("src", component);
const generatedRoot = ".generated";
mkdirSync(sourceRoot, { recursive: true });
mkdirSync(generatedRoot, { recursive: true });
const imports = [];
const names = [];
for (let i = 0; i < 120; i += 1) {
  const name = "value" + String(i).padStart(3, "0");
  const relative = "module-" + String(i).padStart(3, "0") + ".ts";
  const source = component === "reporting" && i === 0
    ? "export const " + name + ": number = \"not-a-number\";\n"
    : "export const " + name + ": number = " + (i + 1) + ";\n";
  writeFileSync(path.join(sourceRoot, relative), source);
  imports.push('import { ' + name + ' } from "./' + relative.slice(0, -3) + '";');
  names.push(name);
}
writeFileSync(path.join(sourceRoot, "index.ts"), imports.join("\n") + "\nexport const moduleCount: number = 120;\nexport const total: number = " + names.join(" + ") + ";\n");
const configPath = path.join(generatedRoot, "tsconfig-" + component + ".json");
const configSourceRoot = path.relative(generatedRoot, sourceRoot).replaceAll("\\", "/");
const config = {
  compilerOptions: {
    target: "ES2022",
    module: "ESNext",
    moduleResolution: "Bundler",
    strict: true,
    noEmit: true,
    skipLibCheck: true
  },
  include: [configSourceRoot + "/**/*.ts"]
};
writeFileSync(configPath, JSON.stringify(config, null, 2) + "\n");
function runTool(name, args) {
  if (process.platform === "win32") {
    return spawnSync(process.env.ComSpec || "cmd.exe", ["/d", "/c", [name + ".cmd", ...args].join(" ")], {
      encoding: "utf8",
      maxBuffer: 1024 * 1024
    });
  }
  return spawnSync(name, args, { encoding: "utf8", maxBuffer: 1024 * 1024 });
}
const result = runTool("tsc", ["--noEmit", "--pretty", "false", "--listFiles", "-p", configPath.replaceAll("\\", "/")]);
const output = (result.stdout || "") + (result.stderr || "");
if (output) process.stdout.write(output);
const normalized = output.replaceAll("\\", "/").toLowerCase();
const sourceMarker = ("/src/" + component + "/").toLowerCase();
const listed = normalized.split(/\r?\n/).filter((line) => line.includes(sourceMarker)).length;
const matches = [...output.matchAll(/^(.+?)\((\d+),(\d+)\): error (TS\d+):/gm)];
const first = matches[0];
let diagnosticFile = null;
if (first) {
  const absolute = path.resolve(first[1]);
  diagnosticFile = path.relative(process.cwd(), absolute).replaceAll("\\", "/");
}
const exitCode = result.status ?? 1;
console.log("SUMMARY " + JSON.stringify({
  component,
  source_files_listed: listed,
  diagnostic_count: matches.length,
  diagnostic_code: first?.[4] ?? null,
  diagnostic_file: diagnosticFile,
  diagnostic_line: first ? Number(first[2]) : null,
  exit_code: exitCode
}));
process.exitCode = exitCode;
