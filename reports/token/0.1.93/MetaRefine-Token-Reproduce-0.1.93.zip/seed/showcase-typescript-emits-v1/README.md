# TypeScript emitted-file inventory

Each component command generates a small import graph in the copied workspace and runs TypeScript with declaration output and --listEmittedFiles. The emitted paths and summary are read from the actual compiler output; generated files are not part of the seed.