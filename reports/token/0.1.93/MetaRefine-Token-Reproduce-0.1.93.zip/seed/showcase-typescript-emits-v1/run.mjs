import { mkdirSync, writeFileSync, existsSync } from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const components = ["orders", "billing", "inventory", "shipping", "accounts", "reporting"];
const component = process.argv[3];
if (process.argv[2] !== "build" || !components.includes(component)) {
  console.error("usage: npm run build -- <component>");
  process.exit(2);
}
const sourceRoot = path.join("src", component);
const generatedRoot = ".generated";
mkdirSync(generatedRoot, { recursive: true });
mkdirSync(sourceRoot, { recursive: true });
const imports = [];
const names = [];
for (let i = 0; i < 48; i += 1) {
  const name = "value" + String(i).padStart(3, "0");
  const relative = "module-" + String(i).padStart(3, "0") + ".ts";
  writeFileSync(path.join(sourceRoot, relative), "export const " + name + ": number = " + (i + 1) + ";\n");
  imports.push('import { ' + name + ' } from "./' + relative.slice(0, -3) + '";');
  names.push(name);
}
writeFileSync(path.join(sourceRoot, "index.ts"), imports.join("\n") + "\nexport const moduleCount: number = 48;\nexport const total: number = " + names.join(" + ") + ";\n");
const configPath = path.join(generatedRoot, "tsconfig-" + component + ".json");
const configSourceRoot = path.relative(generatedRoot, sourceRoot).replaceAll("\\", "/");
const configOutputRoot = path.relative(generatedRoot, path.join("dist", component)).replaceAll("\\", "/");
const config = {
  compilerOptions: {
    target: "ES2022",
    module: "ESNext",
    moduleResolution: "Bundler",
    strict: true,
    declaration: true,
    rootDir: configSourceRoot,
    outDir: configOutputRoot,
    skipLibCheck: true,
    noEmitOnError: true
  },
  include: [configSourceRoot + "/**/*.ts"]
};
writeFileSync(configPath, JSON.stringify(config, null, 2) + "\n");

function runTool(name, args) {
  if (process.platform === "win32") {
    return spawnSync(process.env.ComSpec || "cmd.exe", ["/d", "/c", [name + ".cmd", ...args].join(" ")], {
      encoding: "utf8",
      maxBuffer: 1024 * 1024
    });
  }
  return spawnSync(name, args, { encoding: "utf8", maxBuffer: 1024 * 1024 });
}
const result = runTool("tsc", ["--listEmittedFiles", "-p", configPath.replaceAll("\\", "/")]);
const output = (result.stdout || "") + (result.stderr || "");
if (output) process.stdout.write(output);
const emitted = [...output.matchAll(/^TSFILE:\s*(.+)$/gm)].map((match) => match[1].trim());
const present = emitted.filter((file) => existsSync(path.resolve(file))).length;
const exitCode = result.status ?? 1;
console.log("SUMMARY " + JSON.stringify({
  component,
  files_emitted: emitted.length,
  files_present: present,
  exit_code: exitCode
}));
process.exitCode = exitCode;
