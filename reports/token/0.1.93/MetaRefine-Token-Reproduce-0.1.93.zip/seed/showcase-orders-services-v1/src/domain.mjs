export function orderTotal(lines) {
  return lines.reduce((sum, line) => sum + line.quantity * line.unitCents, 0);
}
export function netDue(chargedCents, refundedCents) {
  return chargedCents - refundedCents;
}
export function availableUnits(onHand, reserved) {
  return onHand - reserved;
}
export function deliveryDays(zone, expedited) {
  const base = { local: 1, regional: 3, national: 5 }[zone];
  return base - (expedited ? 1 : 0);
}
export function ledgerBalance(entries) {
  return entries.reduce((sum, entry) => sum + entry, 0);
}
export function countStatus(rows, status) {
  return rows.filter((row) => row === status).length;
}