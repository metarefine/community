import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { spawnSync } from "node:child_process";

const components = ["orders", "billing", "inventory", "shipping", "accounts", "reporting"];
const action = process.argv[2];
const component = process.argv[3];
if (action !== "test" || !components.includes(component)) {
  console.error("usage: npm test -- <orders|billing|inventory|shipping|accounts|reporting>");
  process.exit(2);
}

const generated = path.join(".generated");
await mkdir(generated, { recursive: true });
const lines = [
  'import test from "node:test";',
  'import assert from "node:assert/strict";',
  'import * as domain from "../src/domain.mjs";'
];
for (let i = 0; i < 300; i += 1) {
  let expression;
  let expected;
  if (component === "orders") {
    const quantity = (i % 5) + 1;
    const unitCents = 100 + (i % 17);
    expression = 'domain.orderTotal([{quantity:' + quantity + ',unitCents:' + unitCents + '},{quantity:1,unitCents:25}])';
    expected = quantity * unitCents + 25;
  } else if (component === "billing") {
    const charged = 10000 + i;
    const refunded = i % 97;
    expression = "domain.netDue(" + charged + "," + refunded + ")";
    expected = charged - refunded;
  } else if (component === "inventory") {
    const onHand = 500 + i;
    const reserved = i % 31;
    expression = "domain.availableUnits(" + onHand + "," + reserved + ")";
    expected = onHand - reserved;
  } else if (component === "shipping") {
    const zone = ["local", "regional", "national"][i % 3];
    const expedited = i % 2 === 0;
    expression = "domain.deliveryDays(" + JSON.stringify(zone) + "," + expedited + ")";
    expected = ({ local: 1, regional: 3, national: 5 })[zone] - (expedited ? 1 : 0);
  } else if (component === "accounts") {
    const entries = [i + 12, -(i % 11), 33];
    expression = "domain.ledgerBalance(" + JSON.stringify(entries) + ")";
    expected = entries.reduce((sum, value) => sum + value, 0);
  } else {
    const rows = Array.from({ length: 15 }, (_, offset) => ["open", "closed", "pending"][(i + offset) % 3]);
    expression = "domain.countStatus(" + JSON.stringify(rows) + ',"open")';
    expected = rows.filter((row) => row === "open").length;
  }
  const label = component + "-" + String(i + 1).padStart(3, "0");
  lines.push('test("' + label + '", () => assert.equal(' + expression + "," + expected + "));");
}
const testFile = path.join(generated, component + ".test.mjs");
await writeFile(testFile, lines.join("\n") + "\n", "utf8");
const result = spawnSync(process.execPath, ["--test", "--test-reporter=tap", testFile], {
  encoding: "utf8",
  maxBuffer: 1024 * 1024
});
const output = (result.stdout || "") + (result.stderr || "");
if (result.stdout) process.stdout.write(result.stdout);
if (result.stderr) process.stderr.write(result.stderr);
const count = (name) => {
  const match = output.match(new RegExp("^# " + name + " (\\d+)$", "m"));
  return match ? Number(match[1]) : null;
};
const exitCode = result.status ?? 1;
console.log("SUMMARY " + JSON.stringify({
  component,
  tests: count("tests"),
  pass: count("pass"),
  fail: count("fail"),
  exit_code: exitCode
}));
process.exitCode = exitCode;