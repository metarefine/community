# Multi-component order regression

This seed creates six independent Node TAP runs. Each command generates 300 deterministic assertions in the copied workspace and exercises the corresponding exported service function. Generated tests live under .generated and are not part of the seed.