import { mkdirSync, writeFileSync, readFileSync, statSync, existsSync } from "node:fs";
import { spawnSync } from "node:child_process";
import path from "node:path";

const components = ["orders", "billing", "inventory", "shipping", "accounts", "reporting"];
const component = process.argv[3];
if (process.argv[2] !== "build" || !components.includes(component)) {
  console.error("usage: npm run build -- <component>");
  process.exit(2);
}
const generatedRoot = path.join(".generated", component);
const sourceRoot = path.join(generatedRoot, "src");
const distRoot = "dist";
mkdirSync(sourceRoot, { recursive: true });
mkdirSync(distRoot, { recursive: true });
const imports = [];
const names = [];
for (let i = 0; i < 64; i += 1) {
  const name = "value" + String(i).padStart(3, "0");
  const relative = "module-" + String(i).padStart(3, "0") + ".ts";
  writeFileSync(path.join(sourceRoot, relative), "export const " + name + ": number = " + (i + 1) + ";\n");
  imports.push('import { ' + name + ' } from "./' + relative.slice(0, -3) + '";');
  names.push(name);
}
const entry = path.join(sourceRoot, "index.ts");
writeFileSync(entry, imports.join("\n") + "\nexport const moduleCount = 64;\nexport const total = " + names.join(" + ") + ";\n");

const outfile = path.join(distRoot, component + ".mjs");
const metafilePath = path.join(".generated", component + ".metafile.json");
const cli = process.platform === "win32" ? "esbuild.cmd" : "esbuild";
const args = [
  entry,
  "--bundle",
  "--platform=node",
  "--format=esm",
  "--outfile=" + outfile,
  "--metafile=" + metafilePath,
  "--log-level=verbose"
];
const result = process.platform === "win32"
  ? spawnSync(process.env.ComSpec || "cmd.exe", ["/d", "/c", [cli, ...args].join(" ")], { encoding: "utf8" })
  : spawnSync(cli, args, { encoding: "utf8" });
if (result.error) throw result.error;
if (result.stdout) process.stdout.write(result.stdout);
if (result.stderr) process.stdout.write(result.stderr);
let metafile = { inputs: {}, outputs: {} };
if (existsSync(metafilePath)) metafile = JSON.parse(readFileSync(metafilePath, "utf8"));
const inputs = Object.keys(metafile.inputs).filter((name) => name.replaceAll("\\", "/").includes(".generated/" + component + "/src/"));
const outputs = Object.keys(metafile.outputs);
const outputBytes = existsSync(outfile) ? statSync(outfile).size : 0;
console.log("SUMMARY " + JSON.stringify({
  component,
  input_modules: inputs.length,
  output_files: outputs.length,
  output_bytes: outputBytes,
  exit_code: result.status ?? 1
}));
if (result.status !== 0) process.exitCode = result.status ?? 1;
