# Component bundle task

This workspace contains deterministic component build commands. Each provided npm command generates build inputs and invokes the configured bundler. Use the actual command output and reported process status to determine results; do not infer outcomes from implementation details.
