# MetaRefine 0.1.93 WorkBuddy 复现包

本包提供五类固定开发任务、seed、完整提示和答案预期，配套 MetaRefine 0.1.93 Token 对照报告。

## 固定工具版本

Node.js 24.20.0、TypeScript 6.0.3、ESLint 10.10.0、esbuild 0.28.2。先准备 Node.js 与 npm，再把固定版本的 TypeScript、ESLint、esbuild 安装在 seed 之外的独立工具目录：

```powershell
$toolRoot = Join-Path $env:LOCALAPPDATA 'mr-eval-tools-showcase'
npm install --prefix $toolRoot --no-save --no-package-lock typescript@6.0.3 eslint@10.10.0 esbuild@0.28.2
$env:Path = (Join-Path $toolRoot 'node_modules\.bin') + ';' + $env:Path
```

在启动 WorkBuddy 前准备好 Node.js 和 `$toolRoot\node_modules\.bin`，确保 WorkBuddy 进程继承该 PATH；已运行的 WorkBuddy 不会自动取得后来修改的 PATH。不要在 seed 中执行 `npm install`。

## 两臂复现

每个 case 的 OFF 与 ON 都从同一 seed 复制到独立、全新的 workspace，并使用新的 WorkBuddy 会话。固定方案为标准整理，模型为 `mr-deepseek`。OFF 时关闭“上下文整理”和“工具结果精简”；ON 时同时开启这两个选项；其他设置保持一致。两臂使用同一 WorkBuddy 与模型，结束后恢复原设置。按完整 prompt 和表格顺序逐条单独运行六条 Bash 命令，不合并、不并行、不改写。

| case ID | 六次 Bash 调用，按顺序 |
| --- | --- |
| `showcase-orders-services-v1` | `npm test -- orders` → `npm test -- billing` → `npm test -- inventory` → `npm test -- shipping` → `npm test -- accounts` → `npm test -- reporting` |
| `showcase-typescript-emits-v1` | `npm run build -- orders` → `npm run build -- billing` → `npm run build -- inventory` → `npm run build -- shipping` → `npm run build -- accounts` → `npm run build -- reporting` |
| `showcase-eslint-ci-logs-v5` | `npm run lint -- orders` → `npm run lint -- billing` → `npm run lint -- inventory` → `npm run lint -- shipping` → `npm run lint -- accounts` → `npm run lint -- reporting` |
| `showcase-typescript-diagnostic-v2` | `npm run build -- orders` → `npm run build -- billing` → `npm run build -- inventory` → `npm run build -- shipping` → `npm run build -- accounts` → `npm run build -- reporting` |
| `showcase-module-bundles-v2` | `npm run build -- orders` → `npm run build -- billing` → `npm run build -- inventory` → `npm run build -- shipping` → `npm run build -- accounts` → `npm run build -- reporting` |

The ESLint case passes through the actual stylish/debug output merged by `cmd.exe` with `2>&1`; it does not add generated log text.

## 答案与用量

按对应 case 的 `expected` 精确核对 `answer.json`：字段、值和 JSON 类型都必须一致，缺少字段或 `null` 不等于真实退出码。报告用 MetaRefine 完整任务逐请求 usage 回执汇总；复现时可读取 WorkBuddy 最终 `result.usage` 的 `input_tokens` 和 `output_tokens`，并在暂停其他客户端时与 MetaRefine 用量计数前后差交叉核对。完整任务包含全部请求及必要恢复/后续请求；`total_tokens = input_tokens + output_tokens`，缓存输入已包含在 `input_tokens`，不要重复累加。缺少真实 usage 时记为 unknown，不要用输出字节数或字符数换算 Token。

`cases.json` 保留任务定义和 expected；`SHA256SUMS.txt` 列出本包其他每个文件的 SHA-256。
