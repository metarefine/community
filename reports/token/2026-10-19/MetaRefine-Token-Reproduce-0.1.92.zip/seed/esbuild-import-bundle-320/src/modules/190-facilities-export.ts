export const record = Object.freeze({
  id: "facilities.export",
  label: "Facilities Export",
  domain: "facilities",
  action: "export",
  sequence: 190,
});
