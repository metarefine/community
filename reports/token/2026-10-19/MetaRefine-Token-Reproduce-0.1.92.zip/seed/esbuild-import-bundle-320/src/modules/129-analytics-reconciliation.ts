export const record = Object.freeze({
  id: "analytics.reconciliation",
  label: "Analytics Reconciliation",
  domain: "analytics",
  action: "reconciliation",
  sequence: 129,
});
