export const record = Object.freeze({
  id: "inventory.reconciliation",
  label: "Inventory Reconciliation",
  domain: "inventory",
  action: "reconciliation",
  sequence: 9,
});
