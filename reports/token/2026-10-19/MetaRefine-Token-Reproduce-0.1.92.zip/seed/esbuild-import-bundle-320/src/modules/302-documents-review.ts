export const record = Object.freeze({
  id: "documents.review",
  label: "Documents Review",
  domain: "documents",
  action: "review",
  sequence: 302,
});
