export const record = Object.freeze({
  id: "security.approval",
  label: "Security Approval",
  domain: "security",
  action: "approval",
  sequence: 103,
});
