export const record = Object.freeze({
  id: "subscriptions.intake",
  label: "Subscriptions Intake",
  domain: "subscriptions",
  action: "intake",
  sequence: 231,
});
