export const record = Object.freeze({
  id: "imports.intake",
  label: "Imports Intake",
  domain: "imports",
  action: "intake",
  sequence: 271,
});
