export const record = Object.freeze({
  id: "subscriptions.reconciliation",
  label: "Subscriptions Reconciliation",
  domain: "subscriptions",
  action: "reconciliation",
  sequence: 239,
});
