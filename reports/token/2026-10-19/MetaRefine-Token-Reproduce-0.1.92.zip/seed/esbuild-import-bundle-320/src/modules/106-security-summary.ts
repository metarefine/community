export const record = Object.freeze({
  id: "security.summary",
  label: "Security Summary",
  domain: "security",
  action: "summary",
  sequence: 106,
});
