export const record = Object.freeze({
  id: "imports.export",
  label: "Imports Export",
  domain: "imports",
  action: "export",
  sequence: 280,
});
