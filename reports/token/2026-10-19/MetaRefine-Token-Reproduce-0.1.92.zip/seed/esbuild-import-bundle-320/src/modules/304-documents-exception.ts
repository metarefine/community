export const record = Object.freeze({
  id: "documents.exception",
  label: "Documents Exception",
  domain: "documents",
  action: "exception",
  sequence: 304,
});
