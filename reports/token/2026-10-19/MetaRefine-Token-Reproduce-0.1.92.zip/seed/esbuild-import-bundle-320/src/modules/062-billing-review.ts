export const record = Object.freeze({
  id: "billing.review",
  label: "Billing Review",
  domain: "billing",
  action: "review",
  sequence: 62,
});
