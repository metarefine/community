export const record = Object.freeze({
  id: "releases.history",
  label: "Releases History",
  domain: "releases",
  action: "history",
  sequence: 95,
});
