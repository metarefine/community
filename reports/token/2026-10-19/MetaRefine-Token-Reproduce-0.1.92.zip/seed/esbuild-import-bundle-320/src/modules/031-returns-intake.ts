export const record = Object.freeze({
  id: "returns.intake",
  label: "Returns Intake",
  domain: "returns",
  action: "intake",
  sequence: 31,
});
