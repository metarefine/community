export const record = Object.freeze({
  id: "catalog.intake",
  label: "Catalog Intake",
  domain: "catalog",
  action: "intake",
  sequence: 41,
});
