export const record = Object.freeze({
  id: "shipping.history",
  label: "Shipping History",
  domain: "shipping",
  action: "history",
  sequence: 135,
});
