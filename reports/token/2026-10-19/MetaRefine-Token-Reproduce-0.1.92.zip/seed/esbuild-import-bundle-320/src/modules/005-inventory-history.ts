export const record = Object.freeze({
  id: "inventory.history",
  label: "Inventory History",
  domain: "inventory",
  action: "history",
  sequence: 5,
});
