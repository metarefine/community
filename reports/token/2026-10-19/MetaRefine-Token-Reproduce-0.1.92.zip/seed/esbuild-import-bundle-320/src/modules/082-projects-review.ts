export const record = Object.freeze({
  id: "projects.review",
  label: "Projects Review",
  domain: "projects",
  action: "review",
  sequence: 82,
});
