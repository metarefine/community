export const record = Object.freeze({
  id: "inventory.exception",
  label: "Inventory Exception",
  domain: "inventory",
  action: "exception",
  sequence: 4,
});
