export const record = Object.freeze({
  id: "returns.export",
  label: "Returns Export",
  domain: "returns",
  action: "export",
  sequence: 40,
});
