export const record = Object.freeze({
  id: "imports.summary",
  label: "Imports Summary",
  domain: "imports",
  action: "summary",
  sequence: 276,
});
