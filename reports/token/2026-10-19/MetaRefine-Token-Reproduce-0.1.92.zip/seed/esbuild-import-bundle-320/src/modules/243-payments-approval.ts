export const record = Object.freeze({
  id: "payments.approval",
  label: "Payments Approval",
  domain: "payments",
  action: "approval",
  sequence: 243,
});
