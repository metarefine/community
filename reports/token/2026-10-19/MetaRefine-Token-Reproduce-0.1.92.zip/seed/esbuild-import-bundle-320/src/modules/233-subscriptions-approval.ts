export const record = Object.freeze({
  id: "subscriptions.approval",
  label: "Subscriptions Approval",
  domain: "subscriptions",
  action: "approval",
  sequence: 233,
});
