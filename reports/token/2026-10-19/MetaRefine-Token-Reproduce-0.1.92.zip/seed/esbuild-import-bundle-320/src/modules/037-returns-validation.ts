export const record = Object.freeze({
  id: "returns.validation",
  label: "Returns Validation",
  domain: "returns",
  action: "validation",
  sequence: 37,
});
