export const record = Object.freeze({
  id: "audit.exception",
  label: "Audit Exception",
  domain: "audit",
  action: "exception",
  sequence: 114,
});
