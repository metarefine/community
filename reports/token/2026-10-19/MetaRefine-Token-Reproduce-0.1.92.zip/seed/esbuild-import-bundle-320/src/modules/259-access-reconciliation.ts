export const record = Object.freeze({
  id: "access.reconciliation",
  label: "Access Reconciliation",
  domain: "access",
  action: "reconciliation",
  sequence: 259,
});
