export const record = Object.freeze({
  id: "service.review",
  label: "Service Review",
  domain: "service",
  action: "review",
  sequence: 192,
});
