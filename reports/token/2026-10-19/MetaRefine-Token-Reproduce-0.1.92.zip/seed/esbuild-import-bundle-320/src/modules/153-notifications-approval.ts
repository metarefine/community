export const record = Object.freeze({
  id: "notifications.approval",
  label: "Notifications Approval",
  domain: "notifications",
  action: "approval",
  sequence: 153,
});
