export const record = Object.freeze({
  id: "documents.routing",
  label: "Documents Routing",
  domain: "documents",
  action: "routing",
  sequence: 308,
});
