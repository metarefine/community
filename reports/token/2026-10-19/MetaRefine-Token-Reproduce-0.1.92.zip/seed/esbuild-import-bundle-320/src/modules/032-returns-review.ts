export const record = Object.freeze({
  id: "returns.review",
  label: "Returns Review",
  domain: "returns",
  action: "review",
  sequence: 32,
});
