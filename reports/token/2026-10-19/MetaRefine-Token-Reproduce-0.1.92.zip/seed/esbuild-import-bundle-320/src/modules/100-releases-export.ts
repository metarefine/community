export const record = Object.freeze({
  id: "releases.export",
  label: "Releases Export",
  domain: "releases",
  action: "export",
  sequence: 100,
});
