export const record = Object.freeze({
  id: "exports.export",
  label: "Exports Export",
  domain: "exports",
  action: "export",
  sequence: 290,
});
