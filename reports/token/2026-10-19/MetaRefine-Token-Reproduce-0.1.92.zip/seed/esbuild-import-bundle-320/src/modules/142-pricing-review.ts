export const record = Object.freeze({
  id: "pricing.review",
  label: "Pricing Review",
  domain: "pricing",
  action: "review",
  sequence: 142,
});
