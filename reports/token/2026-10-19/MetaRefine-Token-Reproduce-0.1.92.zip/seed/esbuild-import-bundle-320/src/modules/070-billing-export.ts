export const record = Object.freeze({
  id: "billing.export",
  label: "Billing Export",
  domain: "billing",
  action: "export",
  sequence: 70,
});
