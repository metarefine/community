export const record = Object.freeze({
  id: "facilities.approval",
  label: "Facilities Approval",
  domain: "facilities",
  action: "approval",
  sequence: 183,
});
