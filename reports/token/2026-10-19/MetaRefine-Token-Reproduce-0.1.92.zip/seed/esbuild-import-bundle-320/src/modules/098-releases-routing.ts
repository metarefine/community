export const record = Object.freeze({
  id: "releases.routing",
  label: "Releases Routing",
  domain: "releases",
  action: "routing",
  sequence: 98,
});
