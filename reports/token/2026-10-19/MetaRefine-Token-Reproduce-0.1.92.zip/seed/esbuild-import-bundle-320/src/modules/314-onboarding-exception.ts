export const record = Object.freeze({
  id: "onboarding.exception",
  label: "Onboarding Exception",
  domain: "onboarding",
  action: "exception",
  sequence: 314,
});
