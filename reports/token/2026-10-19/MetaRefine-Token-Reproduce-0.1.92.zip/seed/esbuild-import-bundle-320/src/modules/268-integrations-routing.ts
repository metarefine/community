export const record = Object.freeze({
  id: "integrations.routing",
  label: "Integrations Routing",
  domain: "integrations",
  action: "routing",
  sequence: 268,
});
