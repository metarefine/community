export const record = Object.freeze({
  id: "inventory.approval",
  label: "Inventory Approval",
  domain: "inventory",
  action: "approval",
  sequence: 3,
});
