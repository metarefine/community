export const record = Object.freeze({
  id: "orders.history",
  label: "Orders History",
  domain: "orders",
  action: "history",
  sequence: 15,
});
