export const record = Object.freeze({
  id: "catalog.summary",
  label: "Catalog Summary",
  domain: "catalog",
  action: "summary",
  sequence: 46,
});
