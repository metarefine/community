export const record = Object.freeze({
  id: "exports.summary",
  label: "Exports Summary",
  domain: "exports",
  action: "summary",
  sequence: 286,
});
