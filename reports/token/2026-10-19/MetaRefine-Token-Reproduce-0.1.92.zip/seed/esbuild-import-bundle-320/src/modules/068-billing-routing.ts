export const record = Object.freeze({
  id: "billing.routing",
  label: "Billing Routing",
  domain: "billing",
  action: "routing",
  sequence: 68,
});
