export const record = Object.freeze({
  id: "procurement.export",
  label: "Procurement Export",
  domain: "procurement",
  action: "export",
  sequence: 170,
});
