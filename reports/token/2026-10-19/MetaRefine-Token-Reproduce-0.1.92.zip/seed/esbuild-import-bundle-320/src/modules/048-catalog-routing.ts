export const record = Object.freeze({
  id: "catalog.routing",
  label: "Catalog Routing",
  domain: "catalog",
  action: "routing",
  sequence: 48,
});
