export const record = Object.freeze({
  id: "compliance.routing",
  label: "Compliance Routing",
  domain: "compliance",
  action: "routing",
  sequence: 218,
});
