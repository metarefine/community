export const record = Object.freeze({
  id: "security.routing",
  label: "Security Routing",
  domain: "security",
  action: "routing",
  sequence: 108,
});
