export const record = Object.freeze({
  id: "billing.reconciliation",
  label: "Billing Reconciliation",
  domain: "billing",
  action: "reconciliation",
  sequence: 69,
});
