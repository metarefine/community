export const record = Object.freeze({
  id: "facilities.routing",
  label: "Facilities Routing",
  domain: "facilities",
  action: "routing",
  sequence: 188,
});
