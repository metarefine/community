export const record = Object.freeze({
  id: "onboarding.intake",
  label: "Onboarding Intake",
  domain: "onboarding",
  action: "intake",
  sequence: 311,
});
