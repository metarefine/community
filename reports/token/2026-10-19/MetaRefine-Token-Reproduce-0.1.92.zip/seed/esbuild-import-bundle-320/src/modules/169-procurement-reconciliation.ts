export const record = Object.freeze({
  id: "procurement.reconciliation",
  label: "Procurement Reconciliation",
  domain: "procurement",
  action: "reconciliation",
  sequence: 169,
});
