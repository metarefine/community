export const record = Object.freeze({
  id: "accounts.routing",
  label: "Accounts Routing",
  domain: "accounts",
  action: "routing",
  sequence: 78,
});
