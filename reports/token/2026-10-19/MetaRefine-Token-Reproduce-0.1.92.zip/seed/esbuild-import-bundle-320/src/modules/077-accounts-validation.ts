export const record = Object.freeze({
  id: "accounts.validation",
  label: "Accounts Validation",
  domain: "accounts",
  action: "validation",
  sequence: 77,
});
