export const record = Object.freeze({
  id: "onboarding.summary",
  label: "Onboarding Summary",
  domain: "onboarding",
  action: "summary",
  sequence: 316,
});
