export const record = Object.freeze({
  id: "audit.summary",
  label: "Audit Summary",
  domain: "audit",
  action: "summary",
  sequence: 116,
});
