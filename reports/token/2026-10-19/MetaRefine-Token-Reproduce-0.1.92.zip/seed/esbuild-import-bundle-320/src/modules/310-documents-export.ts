export const record = Object.freeze({
  id: "documents.export",
  label: "Documents Export",
  domain: "documents",
  action: "export",
  sequence: 310,
});
