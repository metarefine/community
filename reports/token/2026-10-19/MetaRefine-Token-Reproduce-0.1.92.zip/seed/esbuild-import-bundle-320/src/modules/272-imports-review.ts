export const record = Object.freeze({
  id: "imports.review",
  label: "Imports Review",
  domain: "imports",
  action: "review",
  sequence: 272,
});
