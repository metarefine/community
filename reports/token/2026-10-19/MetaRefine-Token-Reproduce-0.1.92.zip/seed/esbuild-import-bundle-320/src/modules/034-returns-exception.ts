export const record = Object.freeze({
  id: "returns.exception",
  label: "Returns Exception",
  domain: "returns",
  action: "exception",
  sequence: 34,
});
