export const record = Object.freeze({
  id: "procurement.exception",
  label: "Procurement Exception",
  domain: "procurement",
  action: "exception",
  sequence: 164,
});
