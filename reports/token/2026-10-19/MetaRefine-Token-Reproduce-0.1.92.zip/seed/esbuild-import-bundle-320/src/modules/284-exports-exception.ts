export const record = Object.freeze({
  id: "exports.exception",
  label: "Exports Exception",
  domain: "exports",
  action: "exception",
  sequence: 284,
});
