export const record = Object.freeze({
  id: "workflows.approval",
  label: "Workflows Approval",
  domain: "workflows",
  action: "approval",
  sequence: 293,
});
