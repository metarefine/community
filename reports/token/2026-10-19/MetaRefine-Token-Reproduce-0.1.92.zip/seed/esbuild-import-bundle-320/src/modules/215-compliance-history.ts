export const record = Object.freeze({
  id: "compliance.history",
  label: "Compliance History",
  domain: "compliance",
  action: "history",
  sequence: 215,
});
