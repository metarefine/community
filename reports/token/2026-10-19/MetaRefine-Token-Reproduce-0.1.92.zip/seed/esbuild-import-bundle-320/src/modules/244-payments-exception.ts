export const record = Object.freeze({
  id: "payments.exception",
  label: "Payments Exception",
  domain: "payments",
  action: "exception",
  sequence: 244,
});
