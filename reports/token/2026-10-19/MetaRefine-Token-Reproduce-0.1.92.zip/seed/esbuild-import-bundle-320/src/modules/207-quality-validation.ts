export const record = Object.freeze({
  id: "quality.validation",
  label: "Quality Validation",
  domain: "quality",
  action: "validation",
  sequence: 207,
});
