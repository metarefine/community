export const record = Object.freeze({
  id: "documents.intake",
  label: "Documents Intake",
  domain: "documents",
  action: "intake",
  sequence: 301,
});
