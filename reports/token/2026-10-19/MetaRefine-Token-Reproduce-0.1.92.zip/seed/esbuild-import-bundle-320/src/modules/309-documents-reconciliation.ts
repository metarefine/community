export const record = Object.freeze({
  id: "documents.reconciliation",
  label: "Documents Reconciliation",
  domain: "documents",
  action: "reconciliation",
  sequence: 309,
});
