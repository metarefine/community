export const record = Object.freeze({
  id: "onboarding.reconciliation",
  label: "Onboarding Reconciliation",
  domain: "onboarding",
  action: "reconciliation",
  sequence: 319,
});
