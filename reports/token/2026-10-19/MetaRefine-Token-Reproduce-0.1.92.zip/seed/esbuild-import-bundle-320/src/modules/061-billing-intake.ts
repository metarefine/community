export const record = Object.freeze({
  id: "billing.intake",
  label: "Billing Intake",
  domain: "billing",
  action: "intake",
  sequence: 61,
});
