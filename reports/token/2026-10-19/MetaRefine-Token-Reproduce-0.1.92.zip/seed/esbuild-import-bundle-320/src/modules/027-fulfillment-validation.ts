export const record = Object.freeze({
  id: "fulfillment.validation",
  label: "Fulfillment Validation",
  domain: "fulfillment",
  action: "validation",
  sequence: 27,
});
