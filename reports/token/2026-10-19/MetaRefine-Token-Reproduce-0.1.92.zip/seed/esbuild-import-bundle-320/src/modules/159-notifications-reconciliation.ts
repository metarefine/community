export const record = Object.freeze({
  id: "notifications.reconciliation",
  label: "Notifications Reconciliation",
  domain: "notifications",
  action: "reconciliation",
  sequence: 159,
});
