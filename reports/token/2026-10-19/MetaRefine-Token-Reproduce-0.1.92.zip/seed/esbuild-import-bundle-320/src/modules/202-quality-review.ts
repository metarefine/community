export const record = Object.freeze({
  id: "quality.review",
  label: "Quality Review",
  domain: "quality",
  action: "review",
  sequence: 202,
});
