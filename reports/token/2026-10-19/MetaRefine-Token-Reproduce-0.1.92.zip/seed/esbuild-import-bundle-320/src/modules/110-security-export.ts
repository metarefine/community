export const record = Object.freeze({
  id: "security.export",
  label: "Security Export",
  domain: "security",
  action: "export",
  sequence: 110,
});
