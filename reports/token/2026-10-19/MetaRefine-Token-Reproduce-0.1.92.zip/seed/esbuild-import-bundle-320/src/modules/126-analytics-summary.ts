export const record = Object.freeze({
  id: "analytics.summary",
  label: "Analytics Summary",
  domain: "analytics",
  action: "summary",
  sequence: 126,
});
