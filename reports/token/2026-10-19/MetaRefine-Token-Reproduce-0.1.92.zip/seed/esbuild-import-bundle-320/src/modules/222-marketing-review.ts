export const record = Object.freeze({
  id: "marketing.review",
  label: "Marketing Review",
  domain: "marketing",
  action: "review",
  sequence: 222,
});
