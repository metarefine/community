export const record = Object.freeze({
  id: "releases.summary",
  label: "Releases Summary",
  domain: "releases",
  action: "summary",
  sequence: 96,
});
