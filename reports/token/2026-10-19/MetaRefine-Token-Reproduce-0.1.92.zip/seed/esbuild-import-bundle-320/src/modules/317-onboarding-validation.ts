export const record = Object.freeze({
  id: "onboarding.validation",
  label: "Onboarding Validation",
  domain: "onboarding",
  action: "validation",
  sequence: 317,
});
