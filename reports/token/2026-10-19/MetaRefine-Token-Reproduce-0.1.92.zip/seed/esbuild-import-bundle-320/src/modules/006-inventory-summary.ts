export const record = Object.freeze({
  id: "inventory.summary",
  label: "Inventory Summary",
  domain: "inventory",
  action: "summary",
  sequence: 6,
});
