export const record = Object.freeze({
  id: "analytics.intake",
  label: "Analytics Intake",
  domain: "analytics",
  action: "intake",
  sequence: 121,
});
