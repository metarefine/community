export const record = Object.freeze({
  id: "service.intake",
  label: "Service Intake",
  domain: "service",
  action: "intake",
  sequence: 191,
});
