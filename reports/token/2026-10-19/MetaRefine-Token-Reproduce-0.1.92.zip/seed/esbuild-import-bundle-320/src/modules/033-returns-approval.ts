export const record = Object.freeze({
  id: "returns.approval",
  label: "Returns Approval",
  domain: "returns",
  action: "approval",
  sequence: 33,
});
