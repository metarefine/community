export const record = Object.freeze({
  id: "analytics.exception",
  label: "Analytics Exception",
  domain: "analytics",
  action: "exception",
  sequence: 124,
});
