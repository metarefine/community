export const record = Object.freeze({
  id: "audit.review",
  label: "Audit Review",
  domain: "audit",
  action: "review",
  sequence: 112,
});
