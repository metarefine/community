export const record = Object.freeze({
  id: "integrations.exception",
  label: "Integrations Exception",
  domain: "integrations",
  action: "exception",
  sequence: 264,
});
