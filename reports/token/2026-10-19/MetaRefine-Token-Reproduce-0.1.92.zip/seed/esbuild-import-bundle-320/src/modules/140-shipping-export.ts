export const record = Object.freeze({
  id: "shipping.export",
  label: "Shipping Export",
  domain: "shipping",
  action: "export",
  sequence: 140,
});
