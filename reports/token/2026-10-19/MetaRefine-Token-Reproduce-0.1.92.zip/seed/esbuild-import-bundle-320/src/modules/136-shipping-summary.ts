export const record = Object.freeze({
  id: "shipping.summary",
  label: "Shipping Summary",
  domain: "shipping",
  action: "summary",
  sequence: 136,
});
