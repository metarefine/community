export const record = Object.freeze({
  id: "pricing.exception",
  label: "Pricing Exception",
  domain: "pricing",
  action: "exception",
  sequence: 144,
});
