export const record = Object.freeze({
  id: "support.review",
  label: "Support Review",
  domain: "support",
  action: "review",
  sequence: 52,
});
