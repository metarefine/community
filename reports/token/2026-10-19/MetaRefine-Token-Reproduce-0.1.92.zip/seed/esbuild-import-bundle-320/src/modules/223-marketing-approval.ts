export const record = Object.freeze({
  id: "marketing.approval",
  label: "Marketing Approval",
  domain: "marketing",
  action: "approval",
  sequence: 223,
});
