export const record = Object.freeze({
  id: "exports.review",
  label: "Exports Review",
  domain: "exports",
  action: "review",
  sequence: 282,
});
