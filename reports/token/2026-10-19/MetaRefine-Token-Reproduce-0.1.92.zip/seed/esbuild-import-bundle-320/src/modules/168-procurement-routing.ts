export const record = Object.freeze({
  id: "procurement.routing",
  label: "Procurement Routing",
  domain: "procurement",
  action: "routing",
  sequence: 168,
});
