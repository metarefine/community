export const record = Object.freeze({
  id: "shipping.validation",
  label: "Shipping Validation",
  domain: "shipping",
  action: "validation",
  sequence: 137,
});
