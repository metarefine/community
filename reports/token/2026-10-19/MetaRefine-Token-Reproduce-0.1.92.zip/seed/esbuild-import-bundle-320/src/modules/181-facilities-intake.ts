export const record = Object.freeze({
  id: "facilities.intake",
  label: "Facilities Intake",
  domain: "facilities",
  action: "intake",
  sequence: 181,
});
