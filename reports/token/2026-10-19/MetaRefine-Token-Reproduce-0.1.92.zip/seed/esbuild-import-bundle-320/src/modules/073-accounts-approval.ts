export const record = Object.freeze({
  id: "accounts.approval",
  label: "Accounts Approval",
  domain: "accounts",
  action: "approval",
  sequence: 73,
});
