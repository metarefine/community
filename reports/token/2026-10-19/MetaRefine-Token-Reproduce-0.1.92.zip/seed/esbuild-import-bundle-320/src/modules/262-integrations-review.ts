export const record = Object.freeze({
  id: "integrations.review",
  label: "Integrations Review",
  domain: "integrations",
  action: "review",
  sequence: 262,
});
