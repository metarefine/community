export const record = Object.freeze({
  id: "inventory.validation",
  label: "Inventory Validation",
  domain: "inventory",
  action: "validation",
  sequence: 7,
});
