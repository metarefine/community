export const record = Object.freeze({
  id: "integrations.reconciliation",
  label: "Integrations Reconciliation",
  domain: "integrations",
  action: "reconciliation",
  sequence: 269,
});
