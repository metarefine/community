export const record = Object.freeze({
  id: "compliance.export",
  label: "Compliance Export",
  domain: "compliance",
  action: "export",
  sequence: 220,
});
