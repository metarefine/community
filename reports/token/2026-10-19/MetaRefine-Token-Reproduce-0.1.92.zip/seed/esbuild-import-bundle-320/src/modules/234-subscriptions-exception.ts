export const record = Object.freeze({
  id: "subscriptions.exception",
  label: "Subscriptions Exception",
  domain: "subscriptions",
  action: "exception",
  sequence: 234,
});
