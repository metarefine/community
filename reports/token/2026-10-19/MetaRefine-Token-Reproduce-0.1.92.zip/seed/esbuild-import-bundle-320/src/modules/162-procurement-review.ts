export const record = Object.freeze({
  id: "procurement.review",
  label: "Procurement Review",
  domain: "procurement",
  action: "review",
  sequence: 162,
});
