export const record = Object.freeze({
  id: "workflows.review",
  label: "Workflows Review",
  domain: "workflows",
  action: "review",
  sequence: 292,
});
