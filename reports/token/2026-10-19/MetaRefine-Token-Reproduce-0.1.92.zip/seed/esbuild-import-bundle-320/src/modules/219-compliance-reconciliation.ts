export const record = Object.freeze({
  id: "compliance.reconciliation",
  label: "Compliance Reconciliation",
  domain: "compliance",
  action: "reconciliation",
  sequence: 219,
});
