export const record = Object.freeze({
  id: "payments.summary",
  label: "Payments Summary",
  domain: "payments",
  action: "summary",
  sequence: 246,
});
