export const record = Object.freeze({
  id: "support.reconciliation",
  label: "Support Reconciliation",
  domain: "support",
  action: "reconciliation",
  sequence: 59,
});
