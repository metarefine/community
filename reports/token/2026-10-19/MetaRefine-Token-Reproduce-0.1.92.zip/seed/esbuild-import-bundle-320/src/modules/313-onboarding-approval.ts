export const record = Object.freeze({
  id: "onboarding.approval",
  label: "Onboarding Approval",
  domain: "onboarding",
  action: "approval",
  sequence: 313,
});
