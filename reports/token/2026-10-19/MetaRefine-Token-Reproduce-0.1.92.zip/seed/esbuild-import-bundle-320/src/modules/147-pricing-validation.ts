export const record = Object.freeze({
  id: "pricing.validation",
  label: "Pricing Validation",
  domain: "pricing",
  action: "validation",
  sequence: 147,
});
