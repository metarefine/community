export const record = Object.freeze({
  id: "workflows.reconciliation",
  label: "Workflows Reconciliation",
  domain: "workflows",
  action: "reconciliation",
  sequence: 299,
});
