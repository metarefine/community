export const record = Object.freeze({
  id: "compliance.review",
  label: "Compliance Review",
  domain: "compliance",
  action: "review",
  sequence: 212,
});
