export const record = Object.freeze({
  id: "fulfillment.reconciliation",
  label: "Fulfillment Reconciliation",
  domain: "fulfillment",
  action: "reconciliation",
  sequence: 29,
});
