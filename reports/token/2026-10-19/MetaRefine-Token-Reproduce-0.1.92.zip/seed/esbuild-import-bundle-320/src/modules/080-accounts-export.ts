export const record = Object.freeze({
  id: "accounts.export",
  label: "Accounts Export",
  domain: "accounts",
  action: "export",
  sequence: 80,
});
