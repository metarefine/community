export const record = Object.freeze({
  id: "audit.routing",
  label: "Audit Routing",
  domain: "audit",
  action: "routing",
  sequence: 118,
});
