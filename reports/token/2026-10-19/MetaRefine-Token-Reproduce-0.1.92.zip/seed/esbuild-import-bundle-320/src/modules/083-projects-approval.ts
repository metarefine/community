export const record = Object.freeze({
  id: "projects.approval",
  label: "Projects Approval",
  domain: "projects",
  action: "approval",
  sequence: 83,
});
