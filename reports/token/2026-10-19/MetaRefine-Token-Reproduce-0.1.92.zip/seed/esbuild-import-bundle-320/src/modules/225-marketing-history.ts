export const record = Object.freeze({
  id: "marketing.history",
  label: "Marketing History",
  domain: "marketing",
  action: "history",
  sequence: 225,
});
