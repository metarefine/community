export const record = Object.freeze({
  id: "inventory.review",
  label: "Inventory Review",
  domain: "inventory",
  action: "review",
  sequence: 2,
});
