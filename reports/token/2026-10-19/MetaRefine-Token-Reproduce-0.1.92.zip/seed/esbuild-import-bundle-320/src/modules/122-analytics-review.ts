export const record = Object.freeze({
  id: "analytics.review",
  label: "Analytics Review",
  domain: "analytics",
  action: "review",
  sequence: 122,
});
