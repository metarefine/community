export const record = Object.freeze({
  id: "staffing.reconciliation",
  label: "Staffing Reconciliation",
  domain: "staffing",
  action: "reconciliation",
  sequence: 179,
});
