export const record = Object.freeze({
  id: "imports.validation",
  label: "Imports Validation",
  domain: "imports",
  action: "validation",
  sequence: 277,
});
