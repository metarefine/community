export const record = Object.freeze({
  id: "fulfillment.history",
  label: "Fulfillment History",
  domain: "fulfillment",
  action: "history",
  sequence: 25,
});
