export const record = Object.freeze({
  id: "analytics.routing",
  label: "Analytics Routing",
  domain: "analytics",
  action: "routing",
  sequence: 128,
});
