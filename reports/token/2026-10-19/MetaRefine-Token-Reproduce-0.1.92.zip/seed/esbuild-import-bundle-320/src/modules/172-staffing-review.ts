export const record = Object.freeze({
  id: "staffing.review",
  label: "Staffing Review",
  domain: "staffing",
  action: "review",
  sequence: 172,
});
