export const record = Object.freeze({
  id: "subscriptions.review",
  label: "Subscriptions Review",
  domain: "subscriptions",
  action: "review",
  sequence: 232,
});
