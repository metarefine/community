export const record = Object.freeze({
  id: "facilities.history",
  label: "Facilities History",
  domain: "facilities",
  action: "history",
  sequence: 185,
});
