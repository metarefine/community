export const record = Object.freeze({
  id: "billing.exception",
  label: "Billing Exception",
  domain: "billing",
  action: "exception",
  sequence: 64,
});
