export const record = Object.freeze({
  id: "billing.approval",
  label: "Billing Approval",
  domain: "billing",
  action: "approval",
  sequence: 63,
});
