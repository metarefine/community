export const record = Object.freeze({
  id: "imports.approval",
  label: "Imports Approval",
  domain: "imports",
  action: "approval",
  sequence: 273,
});
