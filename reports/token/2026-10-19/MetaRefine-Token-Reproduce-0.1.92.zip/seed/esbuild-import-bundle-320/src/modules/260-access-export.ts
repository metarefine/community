export const record = Object.freeze({
  id: "access.export",
  label: "Access Export",
  domain: "access",
  action: "export",
  sequence: 260,
});
