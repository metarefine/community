export const record = Object.freeze({
  id: "subscriptions.routing",
  label: "Subscriptions Routing",
  domain: "subscriptions",
  action: "routing",
  sequence: 238,
});
