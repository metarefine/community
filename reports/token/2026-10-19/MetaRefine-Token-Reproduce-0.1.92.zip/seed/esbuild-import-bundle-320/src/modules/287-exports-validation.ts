export const record = Object.freeze({
  id: "exports.validation",
  label: "Exports Validation",
  domain: "exports",
  action: "validation",
  sequence: 287,
});
