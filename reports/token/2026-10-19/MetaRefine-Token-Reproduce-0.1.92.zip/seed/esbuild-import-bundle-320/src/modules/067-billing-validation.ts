export const record = Object.freeze({
  id: "billing.validation",
  label: "Billing Validation",
  domain: "billing",
  action: "validation",
  sequence: 67,
});
