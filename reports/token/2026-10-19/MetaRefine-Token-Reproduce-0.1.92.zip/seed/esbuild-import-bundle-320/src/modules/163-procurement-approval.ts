export const record = Object.freeze({
  id: "procurement.approval",
  label: "Procurement Approval",
  domain: "procurement",
  action: "approval",
  sequence: 163,
});
