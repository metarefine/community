export const record = Object.freeze({
  id: "inventory.export",
  label: "Inventory Export",
  domain: "inventory",
  action: "export",
  sequence: 10,
});
