export const record = Object.freeze({
  id: "marketing.summary",
  label: "Marketing Summary",
  domain: "marketing",
  action: "summary",
  sequence: 226,
});
