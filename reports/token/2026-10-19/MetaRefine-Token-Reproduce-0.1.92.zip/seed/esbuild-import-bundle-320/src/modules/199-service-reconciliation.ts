export const record = Object.freeze({
  id: "service.reconciliation",
  label: "Service Reconciliation",
  domain: "service",
  action: "reconciliation",
  sequence: 199,
});
