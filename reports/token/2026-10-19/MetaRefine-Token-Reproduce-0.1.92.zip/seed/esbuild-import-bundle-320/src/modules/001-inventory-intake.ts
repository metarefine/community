export const record = Object.freeze({
  id: "inventory.intake",
  label: "Inventory Intake",
  domain: "inventory",
  action: "intake",
  sequence: 1,
});
