export const record = Object.freeze({
  id: "notifications.routing",
  label: "Notifications Routing",
  domain: "notifications",
  action: "routing",
  sequence: 158,
});
