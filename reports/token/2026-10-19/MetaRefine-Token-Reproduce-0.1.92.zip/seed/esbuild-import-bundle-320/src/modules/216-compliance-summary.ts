export const record = Object.freeze({
  id: "compliance.summary",
  label: "Compliance Summary",
  domain: "compliance",
  action: "summary",
  sequence: 216,
});
