export const record = Object.freeze({
  id: "catalog.history",
  label: "Catalog History",
  domain: "catalog",
  action: "history",
  sequence: 45,
});
