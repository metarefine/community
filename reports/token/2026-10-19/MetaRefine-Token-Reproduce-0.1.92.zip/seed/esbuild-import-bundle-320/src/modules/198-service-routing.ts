export const record = Object.freeze({
  id: "service.routing",
  label: "Service Routing",
  domain: "service",
  action: "routing",
  sequence: 198,
});
