export const record = Object.freeze({
  id: "pricing.intake",
  label: "Pricing Intake",
  domain: "pricing",
  action: "intake",
  sequence: 141,
});
