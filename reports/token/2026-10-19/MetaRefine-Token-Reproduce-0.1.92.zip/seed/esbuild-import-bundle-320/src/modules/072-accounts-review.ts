export const record = Object.freeze({
  id: "accounts.review",
  label: "Accounts Review",
  domain: "accounts",
  action: "review",
  sequence: 72,
});
