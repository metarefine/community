export const record = Object.freeze({
  id: "payments.routing",
  label: "Payments Routing",
  domain: "payments",
  action: "routing",
  sequence: 248,
});
