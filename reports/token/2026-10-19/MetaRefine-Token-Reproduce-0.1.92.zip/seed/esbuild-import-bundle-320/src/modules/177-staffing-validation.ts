export const record = Object.freeze({
  id: "staffing.validation",
  label: "Staffing Validation",
  domain: "staffing",
  action: "validation",
  sequence: 177,
});
