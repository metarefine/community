export const record = Object.freeze({
  id: "access.routing",
  label: "Access Routing",
  domain: "access",
  action: "routing",
  sequence: 258,
});
