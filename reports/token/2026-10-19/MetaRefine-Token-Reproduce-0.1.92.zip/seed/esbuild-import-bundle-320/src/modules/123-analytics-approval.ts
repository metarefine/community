export const record = Object.freeze({
  id: "analytics.approval",
  label: "Analytics Approval",
  domain: "analytics",
  action: "approval",
  sequence: 123,
});
