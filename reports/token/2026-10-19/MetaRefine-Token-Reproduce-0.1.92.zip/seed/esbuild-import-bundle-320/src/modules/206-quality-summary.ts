export const record = Object.freeze({
  id: "quality.summary",
  label: "Quality Summary",
  domain: "quality",
  action: "summary",
  sequence: 206,
});
