export const record = Object.freeze({
  id: "orders.exception",
  label: "Orders Exception",
  domain: "orders",
  action: "exception",
  sequence: 14,
});
