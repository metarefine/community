export const record = Object.freeze({
  id: "notifications.export",
  label: "Notifications Export",
  domain: "notifications",
  action: "export",
  sequence: 160,
});
