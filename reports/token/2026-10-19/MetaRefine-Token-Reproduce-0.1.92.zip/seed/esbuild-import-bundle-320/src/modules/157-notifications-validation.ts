export const record = Object.freeze({
  id: "notifications.validation",
  label: "Notifications Validation",
  domain: "notifications",
  action: "validation",
  sequence: 157,
});
