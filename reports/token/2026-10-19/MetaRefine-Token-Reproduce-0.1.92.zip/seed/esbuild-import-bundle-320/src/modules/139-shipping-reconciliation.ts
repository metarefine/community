export const record = Object.freeze({
  id: "shipping.reconciliation",
  label: "Shipping Reconciliation",
  domain: "shipping",
  action: "reconciliation",
  sequence: 139,
});
