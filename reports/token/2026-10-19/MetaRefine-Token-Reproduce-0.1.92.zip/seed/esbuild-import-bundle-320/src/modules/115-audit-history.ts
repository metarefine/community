export const record = Object.freeze({
  id: "audit.history",
  label: "Audit History",
  domain: "audit",
  action: "history",
  sequence: 115,
});
