export const record = Object.freeze({
  id: "compliance.intake",
  label: "Compliance Intake",
  domain: "compliance",
  action: "intake",
  sequence: 211,
});
