export const record = Object.freeze({
  id: "billing.summary",
  label: "Billing Summary",
  domain: "billing",
  action: "summary",
  sequence: 66,
});
