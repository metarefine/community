export const record = Object.freeze({
  id: "documents.validation",
  label: "Documents Validation",
  domain: "documents",
  action: "validation",
  sequence: 307,
});
