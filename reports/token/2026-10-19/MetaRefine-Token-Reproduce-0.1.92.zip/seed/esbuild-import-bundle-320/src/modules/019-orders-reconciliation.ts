export const record = Object.freeze({
  id: "orders.reconciliation",
  label: "Orders Reconciliation",
  domain: "orders",
  action: "reconciliation",
  sequence: 19,
});
