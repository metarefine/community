export const record = Object.freeze({
  id: "pricing.routing",
  label: "Pricing Routing",
  domain: "pricing",
  action: "routing",
  sequence: 148,
});
