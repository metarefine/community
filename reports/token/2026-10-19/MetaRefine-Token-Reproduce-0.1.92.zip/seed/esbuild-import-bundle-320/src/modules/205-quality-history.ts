export const record = Object.freeze({
  id: "quality.history",
  label: "Quality History",
  domain: "quality",
  action: "history",
  sequence: 205,
});
