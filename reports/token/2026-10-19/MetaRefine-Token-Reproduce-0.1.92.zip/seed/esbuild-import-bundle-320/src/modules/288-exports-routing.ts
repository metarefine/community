export const record = Object.freeze({
  id: "exports.routing",
  label: "Exports Routing",
  domain: "exports",
  action: "routing",
  sequence: 288,
});
