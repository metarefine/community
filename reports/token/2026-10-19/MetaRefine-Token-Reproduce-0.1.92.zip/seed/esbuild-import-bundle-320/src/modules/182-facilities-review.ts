export const record = Object.freeze({
  id: "facilities.review",
  label: "Facilities Review",
  domain: "facilities",
  action: "review",
  sequence: 182,
});
