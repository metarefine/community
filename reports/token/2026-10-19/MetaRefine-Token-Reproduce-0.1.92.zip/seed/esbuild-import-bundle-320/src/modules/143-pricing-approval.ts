export const record = Object.freeze({
  id: "pricing.approval",
  label: "Pricing Approval",
  domain: "pricing",
  action: "approval",
  sequence: 143,
});
