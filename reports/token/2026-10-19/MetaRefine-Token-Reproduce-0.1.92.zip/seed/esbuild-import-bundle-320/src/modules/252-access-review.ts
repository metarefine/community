export const record = Object.freeze({
  id: "access.review",
  label: "Access Review",
  domain: "access",
  action: "review",
  sequence: 252,
});
