export const record = Object.freeze({
  id: "fulfillment.exception",
  label: "Fulfillment Exception",
  domain: "fulfillment",
  action: "exception",
  sequence: 24,
});
