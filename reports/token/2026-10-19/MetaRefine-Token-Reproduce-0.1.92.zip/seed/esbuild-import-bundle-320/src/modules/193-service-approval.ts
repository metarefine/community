export const record = Object.freeze({
  id: "service.approval",
  label: "Service Approval",
  domain: "service",
  action: "approval",
  sequence: 193,
});
