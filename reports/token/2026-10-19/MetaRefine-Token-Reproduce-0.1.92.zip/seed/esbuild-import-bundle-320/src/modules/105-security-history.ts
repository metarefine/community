export const record = Object.freeze({
  id: "security.history",
  label: "Security History",
  domain: "security",
  action: "history",
  sequence: 105,
});
