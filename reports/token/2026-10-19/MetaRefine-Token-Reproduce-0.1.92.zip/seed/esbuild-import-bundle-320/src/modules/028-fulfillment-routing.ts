export const record = Object.freeze({
  id: "fulfillment.routing",
  label: "Fulfillment Routing",
  domain: "fulfillment",
  action: "routing",
  sequence: 28,
});
