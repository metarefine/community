export const record = Object.freeze({
  id: "releases.validation",
  label: "Releases Validation",
  domain: "releases",
  action: "validation",
  sequence: 97,
});
