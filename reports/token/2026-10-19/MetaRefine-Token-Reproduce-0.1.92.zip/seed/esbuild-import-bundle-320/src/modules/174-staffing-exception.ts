export const record = Object.freeze({
  id: "staffing.exception",
  label: "Staffing Exception",
  domain: "staffing",
  action: "exception",
  sequence: 174,
});
