export const record = Object.freeze({
  id: "marketing.exception",
  label: "Marketing Exception",
  domain: "marketing",
  action: "exception",
  sequence: 224,
});
