export const record = Object.freeze({
  id: "notifications.history",
  label: "Notifications History",
  domain: "notifications",
  action: "history",
  sequence: 155,
});
