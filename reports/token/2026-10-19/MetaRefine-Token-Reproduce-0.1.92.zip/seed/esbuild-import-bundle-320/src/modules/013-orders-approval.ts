export const record = Object.freeze({
  id: "orders.approval",
  label: "Orders Approval",
  domain: "orders",
  action: "approval",
  sequence: 13,
});
