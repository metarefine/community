export const record = Object.freeze({
  id: "documents.approval",
  label: "Documents Approval",
  domain: "documents",
  action: "approval",
  sequence: 303,
});
