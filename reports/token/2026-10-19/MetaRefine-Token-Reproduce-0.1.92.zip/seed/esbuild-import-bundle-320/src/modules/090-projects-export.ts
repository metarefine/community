export const record = Object.freeze({
  id: "projects.export",
  label: "Projects Export",
  domain: "projects",
  action: "export",
  sequence: 90,
});
