export const record = Object.freeze({
  id: "access.validation",
  label: "Access Validation",
  domain: "access",
  action: "validation",
  sequence: 257,
});
