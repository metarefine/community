export const record = Object.freeze({
  id: "marketing.routing",
  label: "Marketing Routing",
  domain: "marketing",
  action: "routing",
  sequence: 228,
});
