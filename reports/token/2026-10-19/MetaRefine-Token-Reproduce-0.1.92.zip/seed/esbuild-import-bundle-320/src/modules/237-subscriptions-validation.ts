export const record = Object.freeze({
  id: "subscriptions.validation",
  label: "Subscriptions Validation",
  domain: "subscriptions",
  action: "validation",
  sequence: 237,
});
