export const record = Object.freeze({
  id: "catalog.validation",
  label: "Catalog Validation",
  domain: "catalog",
  action: "validation",
  sequence: 47,
});
