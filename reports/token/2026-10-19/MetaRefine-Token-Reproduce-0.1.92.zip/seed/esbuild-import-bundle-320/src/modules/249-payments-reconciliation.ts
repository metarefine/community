export const record = Object.freeze({
  id: "payments.reconciliation",
  label: "Payments Reconciliation",
  domain: "payments",
  action: "reconciliation",
  sequence: 249,
});
