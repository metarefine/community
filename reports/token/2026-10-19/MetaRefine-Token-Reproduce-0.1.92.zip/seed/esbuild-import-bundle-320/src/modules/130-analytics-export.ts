export const record = Object.freeze({
  id: "analytics.export",
  label: "Analytics Export",
  domain: "analytics",
  action: "export",
  sequence: 130,
});
