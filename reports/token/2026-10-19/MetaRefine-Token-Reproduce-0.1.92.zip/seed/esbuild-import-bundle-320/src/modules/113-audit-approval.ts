export const record = Object.freeze({
  id: "audit.approval",
  label: "Audit Approval",
  domain: "audit",
  action: "approval",
  sequence: 113,
});
