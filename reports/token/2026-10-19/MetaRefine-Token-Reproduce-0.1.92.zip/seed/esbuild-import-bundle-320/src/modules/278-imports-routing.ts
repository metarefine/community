export const record = Object.freeze({
  id: "imports.routing",
  label: "Imports Routing",
  domain: "imports",
  action: "routing",
  sequence: 278,
});
