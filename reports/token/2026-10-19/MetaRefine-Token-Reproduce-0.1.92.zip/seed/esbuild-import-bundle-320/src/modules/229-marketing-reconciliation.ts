export const record = Object.freeze({
  id: "marketing.reconciliation",
  label: "Marketing Reconciliation",
  domain: "marketing",
  action: "reconciliation",
  sequence: 229,
});
