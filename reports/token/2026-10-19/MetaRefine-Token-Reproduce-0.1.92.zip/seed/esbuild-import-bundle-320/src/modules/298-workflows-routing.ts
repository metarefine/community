export const record = Object.freeze({
  id: "workflows.routing",
  label: "Workflows Routing",
  domain: "workflows",
  action: "routing",
  sequence: 298,
});
