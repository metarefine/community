export const record = Object.freeze({
  id: "workflows.exception",
  label: "Workflows Exception",
  domain: "workflows",
  action: "exception",
  sequence: 294,
});
