export const record = Object.freeze({
  id: "security.exception",
  label: "Security Exception",
  domain: "security",
  action: "exception",
  sequence: 104,
});
