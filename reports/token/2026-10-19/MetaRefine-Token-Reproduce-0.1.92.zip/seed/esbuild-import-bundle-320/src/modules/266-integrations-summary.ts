export const record = Object.freeze({
  id: "integrations.summary",
  label: "Integrations Summary",
  domain: "integrations",
  action: "summary",
  sequence: 266,
});
