export const record = Object.freeze({
  id: "support.history",
  label: "Support History",
  domain: "support",
  action: "history",
  sequence: 55,
});
