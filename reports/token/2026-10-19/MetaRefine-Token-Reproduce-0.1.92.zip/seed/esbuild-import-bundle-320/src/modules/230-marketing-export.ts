export const record = Object.freeze({
  id: "marketing.export",
  label: "Marketing Export",
  domain: "marketing",
  action: "export",
  sequence: 230,
});
