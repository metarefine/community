export const record = Object.freeze({
  id: "pricing.summary",
  label: "Pricing Summary",
  domain: "pricing",
  action: "summary",
  sequence: 146,
});
