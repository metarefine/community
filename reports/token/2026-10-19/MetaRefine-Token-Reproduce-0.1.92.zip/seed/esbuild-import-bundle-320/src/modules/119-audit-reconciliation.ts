export const record = Object.freeze({
  id: "audit.reconciliation",
  label: "Audit Reconciliation",
  domain: "audit",
  action: "reconciliation",
  sequence: 119,
});
