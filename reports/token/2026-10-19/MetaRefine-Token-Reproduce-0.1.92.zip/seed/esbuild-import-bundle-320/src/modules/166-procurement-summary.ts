export const record = Object.freeze({
  id: "procurement.summary",
  label: "Procurement Summary",
  domain: "procurement",
  action: "summary",
  sequence: 166,
});
