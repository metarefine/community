export const record = Object.freeze({
  id: "orders.review",
  label: "Orders Review",
  domain: "orders",
  action: "review",
  sequence: 12,
});
