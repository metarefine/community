export const record = Object.freeze({
  id: "exports.approval",
  label: "Exports Approval",
  domain: "exports",
  action: "approval",
  sequence: 283,
});
