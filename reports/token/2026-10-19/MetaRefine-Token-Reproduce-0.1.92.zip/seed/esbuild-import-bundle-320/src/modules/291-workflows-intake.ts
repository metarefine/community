export const record = Object.freeze({
  id: "workflows.intake",
  label: "Workflows Intake",
  domain: "workflows",
  action: "intake",
  sequence: 291,
});
