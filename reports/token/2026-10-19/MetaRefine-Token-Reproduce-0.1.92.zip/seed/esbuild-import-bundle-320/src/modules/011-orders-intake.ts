export const record = Object.freeze({
  id: "orders.intake",
  label: "Orders Intake",
  domain: "orders",
  action: "intake",
  sequence: 11,
});
