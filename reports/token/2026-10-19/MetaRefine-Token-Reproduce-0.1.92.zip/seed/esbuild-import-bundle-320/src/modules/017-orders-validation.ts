export const record = Object.freeze({
  id: "orders.validation",
  label: "Orders Validation",
  domain: "orders",
  action: "validation",
  sequence: 17,
});
