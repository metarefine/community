export const record = Object.freeze({
  id: "staffing.routing",
  label: "Staffing Routing",
  domain: "staffing",
  action: "routing",
  sequence: 178,
});
