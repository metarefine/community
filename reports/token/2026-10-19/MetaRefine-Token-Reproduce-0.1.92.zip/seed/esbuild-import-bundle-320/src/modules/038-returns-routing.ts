export const record = Object.freeze({
  id: "returns.routing",
  label: "Returns Routing",
  domain: "returns",
  action: "routing",
  sequence: 38,
});
