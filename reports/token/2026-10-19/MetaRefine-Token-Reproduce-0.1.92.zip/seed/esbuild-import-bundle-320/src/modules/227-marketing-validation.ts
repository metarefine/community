export const record = Object.freeze({
  id: "marketing.validation",
  label: "Marketing Validation",
  domain: "marketing",
  action: "validation",
  sequence: 227,
});
