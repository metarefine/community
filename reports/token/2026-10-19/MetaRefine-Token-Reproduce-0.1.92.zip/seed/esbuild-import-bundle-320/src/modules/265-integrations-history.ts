export const record = Object.freeze({
  id: "integrations.history",
  label: "Integrations History",
  domain: "integrations",
  action: "history",
  sequence: 265,
});
