export const record = Object.freeze({
  id: "pricing.reconciliation",
  label: "Pricing Reconciliation",
  domain: "pricing",
  action: "reconciliation",
  sequence: 149,
});
