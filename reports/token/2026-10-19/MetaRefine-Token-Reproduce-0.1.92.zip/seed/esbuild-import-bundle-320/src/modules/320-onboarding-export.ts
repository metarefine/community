export const record = Object.freeze({
  id: "onboarding.export",
  label: "Onboarding Export",
  domain: "onboarding",
  action: "export",
  sequence: 320,
});
