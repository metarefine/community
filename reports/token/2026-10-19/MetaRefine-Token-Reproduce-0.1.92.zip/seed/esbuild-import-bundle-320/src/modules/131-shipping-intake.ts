export const record = Object.freeze({
  id: "shipping.intake",
  label: "Shipping Intake",
  domain: "shipping",
  action: "intake",
  sequence: 131,
});
