export const record = Object.freeze({
  id: "releases.intake",
  label: "Releases Intake",
  domain: "releases",
  action: "intake",
  sequence: 91,
});
