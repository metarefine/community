export const record = Object.freeze({
  id: "audit.intake",
  label: "Audit Intake",
  domain: "audit",
  action: "intake",
  sequence: 111,
});
