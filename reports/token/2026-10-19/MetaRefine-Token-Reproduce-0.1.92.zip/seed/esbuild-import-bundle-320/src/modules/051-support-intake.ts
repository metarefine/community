export const record = Object.freeze({
  id: "support.intake",
  label: "Support Intake",
  domain: "support",
  action: "intake",
  sequence: 51,
});
