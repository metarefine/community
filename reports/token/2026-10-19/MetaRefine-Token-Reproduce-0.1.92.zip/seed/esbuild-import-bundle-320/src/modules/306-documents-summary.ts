export const record = Object.freeze({
  id: "documents.summary",
  label: "Documents Summary",
  domain: "documents",
  action: "summary",
  sequence: 306,
});
