export const record = Object.freeze({
  id: "security.intake",
  label: "Security Intake",
  domain: "security",
  action: "intake",
  sequence: 101,
});
