export const record = Object.freeze({
  id: "pricing.history",
  label: "Pricing History",
  domain: "pricing",
  action: "history",
  sequence: 145,
});
