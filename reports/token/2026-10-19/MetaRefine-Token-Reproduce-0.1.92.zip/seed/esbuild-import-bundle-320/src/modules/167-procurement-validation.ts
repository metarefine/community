export const record = Object.freeze({
  id: "procurement.validation",
  label: "Procurement Validation",
  domain: "procurement",
  action: "validation",
  sequence: 167,
});
