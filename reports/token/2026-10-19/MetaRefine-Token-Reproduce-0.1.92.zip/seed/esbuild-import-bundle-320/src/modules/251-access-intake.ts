export const record = Object.freeze({
  id: "access.intake",
  label: "Access Intake",
  domain: "access",
  action: "intake",
  sequence: 251,
});
