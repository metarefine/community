export const record = Object.freeze({
  id: "quality.export",
  label: "Quality Export",
  domain: "quality",
  action: "export",
  sequence: 210,
});
