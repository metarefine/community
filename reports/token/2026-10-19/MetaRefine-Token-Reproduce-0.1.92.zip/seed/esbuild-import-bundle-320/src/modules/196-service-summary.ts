export const record = Object.freeze({
  id: "service.summary",
  label: "Service Summary",
  domain: "service",
  action: "summary",
  sequence: 196,
});
