export const record = Object.freeze({
  id: "subscriptions.summary",
  label: "Subscriptions Summary",
  domain: "subscriptions",
  action: "summary",
  sequence: 236,
});
