export const record = Object.freeze({
  id: "catalog.review",
  label: "Catalog Review",
  domain: "catalog",
  action: "review",
  sequence: 42,
});
