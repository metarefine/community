export const record = Object.freeze({
  id: "security.validation",
  label: "Security Validation",
  domain: "security",
  action: "validation",
  sequence: 107,
});
