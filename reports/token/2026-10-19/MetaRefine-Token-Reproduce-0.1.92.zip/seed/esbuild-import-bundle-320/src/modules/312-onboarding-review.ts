export const record = Object.freeze({
  id: "onboarding.review",
  label: "Onboarding Review",
  domain: "onboarding",
  action: "review",
  sequence: 312,
});
