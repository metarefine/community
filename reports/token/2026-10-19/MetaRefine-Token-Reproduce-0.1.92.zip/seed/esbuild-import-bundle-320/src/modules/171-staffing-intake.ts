export const record = Object.freeze({
  id: "staffing.intake",
  label: "Staffing Intake",
  domain: "staffing",
  action: "intake",
  sequence: 171,
});
