export const record = Object.freeze({
  id: "quality.approval",
  label: "Quality Approval",
  domain: "quality",
  action: "approval",
  sequence: 203,
});
