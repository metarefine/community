export const record = Object.freeze({
  id: "subscriptions.export",
  label: "Subscriptions Export",
  domain: "subscriptions",
  action: "export",
  sequence: 240,
});
