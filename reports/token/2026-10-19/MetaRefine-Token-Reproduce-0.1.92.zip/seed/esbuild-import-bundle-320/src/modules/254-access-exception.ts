export const record = Object.freeze({
  id: "access.exception",
  label: "Access Exception",
  domain: "access",
  action: "exception",
  sequence: 254,
});
