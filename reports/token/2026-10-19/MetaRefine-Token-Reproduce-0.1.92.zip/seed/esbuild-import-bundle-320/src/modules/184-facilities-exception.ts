export const record = Object.freeze({
  id: "facilities.exception",
  label: "Facilities Exception",
  domain: "facilities",
  action: "exception",
  sequence: 184,
});
