export const record = Object.freeze({
  id: "pricing.export",
  label: "Pricing Export",
  domain: "pricing",
  action: "export",
  sequence: 150,
});
