export const record = Object.freeze({
  id: "support.exception",
  label: "Support Exception",
  domain: "support",
  action: "exception",
  sequence: 54,
});
