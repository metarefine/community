export const record = Object.freeze({
  id: "support.routing",
  label: "Support Routing",
  domain: "support",
  action: "routing",
  sequence: 58,
});
