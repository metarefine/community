export const record = Object.freeze({
  id: "fulfillment.approval",
  label: "Fulfillment Approval",
  domain: "fulfillment",
  action: "approval",
  sequence: 23,
});
