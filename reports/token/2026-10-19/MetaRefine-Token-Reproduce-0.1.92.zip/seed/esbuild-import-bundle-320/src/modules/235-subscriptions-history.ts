export const record = Object.freeze({
  id: "subscriptions.history",
  label: "Subscriptions History",
  domain: "subscriptions",
  action: "history",
  sequence: 235,
});
