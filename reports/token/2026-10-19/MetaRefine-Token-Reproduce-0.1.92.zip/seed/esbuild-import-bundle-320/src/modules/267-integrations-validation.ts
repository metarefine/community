export const record = Object.freeze({
  id: "integrations.validation",
  label: "Integrations Validation",
  domain: "integrations",
  action: "validation",
  sequence: 267,
});
