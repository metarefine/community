export const record = Object.freeze({
  id: "compliance.approval",
  label: "Compliance Approval",
  domain: "compliance",
  action: "approval",
  sequence: 213,
});
