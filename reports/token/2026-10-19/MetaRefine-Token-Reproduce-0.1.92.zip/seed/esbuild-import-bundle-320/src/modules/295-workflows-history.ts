export const record = Object.freeze({
  id: "workflows.history",
  label: "Workflows History",
  domain: "workflows",
  action: "history",
  sequence: 295,
});
