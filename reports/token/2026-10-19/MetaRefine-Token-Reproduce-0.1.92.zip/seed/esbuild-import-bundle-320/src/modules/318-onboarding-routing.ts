export const record = Object.freeze({
  id: "onboarding.routing",
  label: "Onboarding Routing",
  domain: "onboarding",
  action: "routing",
  sequence: 318,
});
