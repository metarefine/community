export const record = Object.freeze({
  id: "catalog.export",
  label: "Catalog Export",
  domain: "catalog",
  action: "export",
  sequence: 50,
});
