export const record = Object.freeze({
  id: "workflows.validation",
  label: "Workflows Validation",
  domain: "workflows",
  action: "validation",
  sequence: 297,
});
