export const record = Object.freeze({
  id: "service.validation",
  label: "Service Validation",
  domain: "service",
  action: "validation",
  sequence: 197,
});
