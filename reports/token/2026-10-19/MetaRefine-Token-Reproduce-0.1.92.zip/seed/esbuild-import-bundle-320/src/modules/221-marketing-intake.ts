export const record = Object.freeze({
  id: "marketing.intake",
  label: "Marketing Intake",
  domain: "marketing",
  action: "intake",
  sequence: 221,
});
