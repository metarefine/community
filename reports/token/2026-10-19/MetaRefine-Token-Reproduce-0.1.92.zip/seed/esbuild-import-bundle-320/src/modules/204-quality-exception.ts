export const record = Object.freeze({
  id: "quality.exception",
  label: "Quality Exception",
  domain: "quality",
  action: "exception",
  sequence: 204,
});
