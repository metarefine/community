export const record = Object.freeze({
  id: "releases.approval",
  label: "Releases Approval",
  domain: "releases",
  action: "approval",
  sequence: 93,
});
