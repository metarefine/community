export const record = Object.freeze({
  id: "integrations.export",
  label: "Integrations Export",
  domain: "integrations",
  action: "export",
  sequence: 270,
});
