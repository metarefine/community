export const record = Object.freeze({
  id: "workflows.summary",
  label: "Workflows Summary",
  domain: "workflows",
  action: "summary",
  sequence: 296,
});
