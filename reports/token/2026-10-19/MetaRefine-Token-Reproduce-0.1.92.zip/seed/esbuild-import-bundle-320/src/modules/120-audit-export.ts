export const record = Object.freeze({
  id: "audit.export",
  label: "Audit Export",
  domain: "audit",
  action: "export",
  sequence: 120,
});
