export const record = Object.freeze({
  id: "fulfillment.intake",
  label: "Fulfillment Intake",
  domain: "fulfillment",
  action: "intake",
  sequence: 21,
});
