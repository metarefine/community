export const record = Object.freeze({
  id: "security.reconciliation",
  label: "Security Reconciliation",
  domain: "security",
  action: "reconciliation",
  sequence: 109,
});
