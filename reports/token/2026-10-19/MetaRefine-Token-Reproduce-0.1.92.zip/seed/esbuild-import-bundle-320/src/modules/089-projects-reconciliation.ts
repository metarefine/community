export const record = Object.freeze({
  id: "projects.reconciliation",
  label: "Projects Reconciliation",
  domain: "projects",
  action: "reconciliation",
  sequence: 89,
});
