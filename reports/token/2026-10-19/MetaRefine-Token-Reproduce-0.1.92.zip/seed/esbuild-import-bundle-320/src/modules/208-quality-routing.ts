export const record = Object.freeze({
  id: "quality.routing",
  label: "Quality Routing",
  domain: "quality",
  action: "routing",
  sequence: 208,
});
