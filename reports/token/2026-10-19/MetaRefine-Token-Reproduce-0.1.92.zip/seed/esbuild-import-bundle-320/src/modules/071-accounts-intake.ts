export const record = Object.freeze({
  id: "accounts.intake",
  label: "Accounts Intake",
  domain: "accounts",
  action: "intake",
  sequence: 71,
});
