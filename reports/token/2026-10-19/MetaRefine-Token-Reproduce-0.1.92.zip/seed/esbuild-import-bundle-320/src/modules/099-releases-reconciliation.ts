export const record = Object.freeze({
  id: "releases.reconciliation",
  label: "Releases Reconciliation",
  domain: "releases",
  action: "reconciliation",
  sequence: 99,
});
