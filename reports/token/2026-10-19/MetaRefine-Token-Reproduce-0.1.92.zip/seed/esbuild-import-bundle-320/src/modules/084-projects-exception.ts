export const record = Object.freeze({
  id: "projects.exception",
  label: "Projects Exception",
  domain: "projects",
  action: "exception",
  sequence: 84,
});
