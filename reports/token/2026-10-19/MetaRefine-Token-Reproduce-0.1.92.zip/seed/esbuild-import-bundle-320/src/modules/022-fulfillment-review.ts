export const record = Object.freeze({
  id: "fulfillment.review",
  label: "Fulfillment Review",
  domain: "fulfillment",
  action: "review",
  sequence: 22,
});
