export const record = Object.freeze({
  id: "analytics.history",
  label: "Analytics History",
  domain: "analytics",
  action: "history",
  sequence: 125,
});
