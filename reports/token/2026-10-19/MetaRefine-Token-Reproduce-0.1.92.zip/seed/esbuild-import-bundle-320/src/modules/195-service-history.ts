export const record = Object.freeze({
  id: "service.history",
  label: "Service History",
  domain: "service",
  action: "history",
  sequence: 195,
});
