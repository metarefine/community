export const record = Object.freeze({
  id: "shipping.routing",
  label: "Shipping Routing",
  domain: "shipping",
  action: "routing",
  sequence: 138,
});
