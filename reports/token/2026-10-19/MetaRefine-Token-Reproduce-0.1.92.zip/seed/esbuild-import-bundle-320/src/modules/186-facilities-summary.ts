export const record = Object.freeze({
  id: "facilities.summary",
  label: "Facilities Summary",
  domain: "facilities",
  action: "summary",
  sequence: 186,
});
