export const record = Object.freeze({
  id: "shipping.approval",
  label: "Shipping Approval",
  domain: "shipping",
  action: "approval",
  sequence: 133,
});
