export const record = Object.freeze({
  id: "facilities.validation",
  label: "Facilities Validation",
  domain: "facilities",
  action: "validation",
  sequence: 187,
});
