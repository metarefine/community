export const record = Object.freeze({
  id: "analytics.validation",
  label: "Analytics Validation",
  domain: "analytics",
  action: "validation",
  sequence: 127,
});
