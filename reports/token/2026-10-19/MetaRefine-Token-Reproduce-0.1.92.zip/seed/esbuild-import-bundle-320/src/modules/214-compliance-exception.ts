export const record = Object.freeze({
  id: "compliance.exception",
  label: "Compliance Exception",
  domain: "compliance",
  action: "exception",
  sequence: 214,
});
