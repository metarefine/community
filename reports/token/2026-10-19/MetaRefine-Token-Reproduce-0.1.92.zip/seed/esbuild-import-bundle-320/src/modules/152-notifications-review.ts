export const record = Object.freeze({
  id: "notifications.review",
  label: "Notifications Review",
  domain: "notifications",
  action: "review",
  sequence: 152,
});
