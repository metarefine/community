export const record = Object.freeze({
  id: "inventory.routing",
  label: "Inventory Routing",
  domain: "inventory",
  action: "routing",
  sequence: 8,
});
