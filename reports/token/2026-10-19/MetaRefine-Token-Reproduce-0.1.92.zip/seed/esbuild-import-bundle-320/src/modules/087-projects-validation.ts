export const record = Object.freeze({
  id: "projects.validation",
  label: "Projects Validation",
  domain: "projects",
  action: "validation",
  sequence: 87,
});
