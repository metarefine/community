export const record = Object.freeze({
  id: "access.summary",
  label: "Access Summary",
  domain: "access",
  action: "summary",
  sequence: 256,
});
