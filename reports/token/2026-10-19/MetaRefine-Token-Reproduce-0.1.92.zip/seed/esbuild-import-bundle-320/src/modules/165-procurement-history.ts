export const record = Object.freeze({
  id: "procurement.history",
  label: "Procurement History",
  domain: "procurement",
  action: "history",
  sequence: 165,
});
