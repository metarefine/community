export const record = Object.freeze({
  id: "projects.history",
  label: "Projects History",
  domain: "projects",
  action: "history",
  sequence: 85,
});
