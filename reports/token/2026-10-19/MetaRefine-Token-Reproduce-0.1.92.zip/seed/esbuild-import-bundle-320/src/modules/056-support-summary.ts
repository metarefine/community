export const record = Object.freeze({
  id: "support.summary",
  label: "Support Summary",
  domain: "support",
  action: "summary",
  sequence: 56,
});
