export const record = Object.freeze({
  id: "integrations.approval",
  label: "Integrations Approval",
  domain: "integrations",
  action: "approval",
  sequence: 263,
});
