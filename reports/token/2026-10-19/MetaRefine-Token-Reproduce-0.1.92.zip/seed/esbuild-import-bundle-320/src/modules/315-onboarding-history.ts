export const record = Object.freeze({
  id: "onboarding.history",
  label: "Onboarding History",
  domain: "onboarding",
  action: "history",
  sequence: 315,
});
