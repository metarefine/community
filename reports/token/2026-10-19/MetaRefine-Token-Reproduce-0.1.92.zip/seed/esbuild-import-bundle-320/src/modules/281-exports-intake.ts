export const record = Object.freeze({
  id: "exports.intake",
  label: "Exports Intake",
  domain: "exports",
  action: "intake",
  sequence: 281,
});
