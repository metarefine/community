export const record = Object.freeze({
  id: "catalog.reconciliation",
  label: "Catalog Reconciliation",
  domain: "catalog",
  action: "reconciliation",
  sequence: 49,
});
