export const record = Object.freeze({
  id: "returns.history",
  label: "Returns History",
  domain: "returns",
  action: "history",
  sequence: 35,
});
