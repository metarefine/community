export const record = Object.freeze({
  id: "accounts.summary",
  label: "Accounts Summary",
  domain: "accounts",
  action: "summary",
  sequence: 76,
});
