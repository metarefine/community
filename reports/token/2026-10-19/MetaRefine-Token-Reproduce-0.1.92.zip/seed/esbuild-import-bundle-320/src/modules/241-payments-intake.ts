export const record = Object.freeze({
  id: "payments.intake",
  label: "Payments Intake",
  domain: "payments",
  action: "intake",
  sequence: 241,
});
