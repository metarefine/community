export const record = Object.freeze({
  id: "orders.routing",
  label: "Orders Routing",
  domain: "orders",
  action: "routing",
  sequence: 18,
});
