export const record = Object.freeze({
  id: "documents.history",
  label: "Documents History",
  domain: "documents",
  action: "history",
  sequence: 305,
});
