export const record = Object.freeze({
  id: "returns.summary",
  label: "Returns Summary",
  domain: "returns",
  action: "summary",
  sequence: 36,
});
