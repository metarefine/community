export const record = Object.freeze({
  id: "workflows.export",
  label: "Workflows Export",
  domain: "workflows",
  action: "export",
  sequence: 300,
});
