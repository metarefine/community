export const record = Object.freeze({
  id: "payments.export",
  label: "Payments Export",
  domain: "payments",
  action: "export",
  sequence: 250,
});
