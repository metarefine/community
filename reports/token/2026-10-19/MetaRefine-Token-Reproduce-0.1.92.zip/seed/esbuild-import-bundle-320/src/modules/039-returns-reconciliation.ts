export const record = Object.freeze({
  id: "returns.reconciliation",
  label: "Returns Reconciliation",
  domain: "returns",
  action: "reconciliation",
  sequence: 39,
});
