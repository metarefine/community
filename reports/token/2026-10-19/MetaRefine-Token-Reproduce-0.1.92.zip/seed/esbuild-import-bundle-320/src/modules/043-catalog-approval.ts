export const record = Object.freeze({
  id: "catalog.approval",
  label: "Catalog Approval",
  domain: "catalog",
  action: "approval",
  sequence: 43,
});
