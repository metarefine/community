export const record = Object.freeze({
  id: "staffing.summary",
  label: "Staffing Summary",
  domain: "staffing",
  action: "summary",
  sequence: 176,
});
