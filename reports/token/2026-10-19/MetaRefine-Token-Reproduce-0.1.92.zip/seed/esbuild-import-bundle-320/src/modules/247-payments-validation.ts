export const record = Object.freeze({
  id: "payments.validation",
  label: "Payments Validation",
  domain: "payments",
  action: "validation",
  sequence: 247,
});
