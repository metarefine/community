export const record = Object.freeze({
  id: "quality.reconciliation",
  label: "Quality Reconciliation",
  domain: "quality",
  action: "reconciliation",
  sequence: 209,
});
