export const record = Object.freeze({
  id: "support.export",
  label: "Support Export",
  domain: "support",
  action: "export",
  sequence: 60,
});
