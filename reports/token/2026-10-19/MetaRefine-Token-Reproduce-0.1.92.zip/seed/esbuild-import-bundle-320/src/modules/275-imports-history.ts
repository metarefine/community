export const record = Object.freeze({
  id: "imports.history",
  label: "Imports History",
  domain: "imports",
  action: "history",
  sequence: 275,
});
