export const record = Object.freeze({
  id: "notifications.summary",
  label: "Notifications Summary",
  domain: "notifications",
  action: "summary",
  sequence: 156,
});
