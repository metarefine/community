export const record = Object.freeze({
  id: "facilities.reconciliation",
  label: "Facilities Reconciliation",
  domain: "facilities",
  action: "reconciliation",
  sequence: 189,
});
