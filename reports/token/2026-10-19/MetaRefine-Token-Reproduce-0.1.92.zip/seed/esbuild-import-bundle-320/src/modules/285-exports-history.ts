export const record = Object.freeze({
  id: "exports.history",
  label: "Exports History",
  domain: "exports",
  action: "history",
  sequence: 285,
});
