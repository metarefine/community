export const record = Object.freeze({
  id: "support.validation",
  label: "Support Validation",
  domain: "support",
  action: "validation",
  sequence: 57,
});
