export const record = Object.freeze({
  id: "staffing.export",
  label: "Staffing Export",
  domain: "staffing",
  action: "export",
  sequence: 180,
});
