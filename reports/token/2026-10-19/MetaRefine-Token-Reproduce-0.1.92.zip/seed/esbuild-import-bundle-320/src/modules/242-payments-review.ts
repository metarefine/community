export const record = Object.freeze({
  id: "payments.review",
  label: "Payments Review",
  domain: "payments",
  action: "review",
  sequence: 242,
});
