export const record = Object.freeze({
  id: "service.export",
  label: "Service Export",
  domain: "service",
  action: "export",
  sequence: 200,
});
