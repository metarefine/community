export const record = Object.freeze({
  id: "security.review",
  label: "Security Review",
  domain: "security",
  action: "review",
  sequence: 102,
});
