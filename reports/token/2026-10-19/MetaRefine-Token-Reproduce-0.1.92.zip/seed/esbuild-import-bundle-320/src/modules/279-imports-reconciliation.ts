export const record = Object.freeze({
  id: "imports.reconciliation",
  label: "Imports Reconciliation",
  domain: "imports",
  action: "reconciliation",
  sequence: 279,
});
