export const record = Object.freeze({
  id: "accounts.history",
  label: "Accounts History",
  domain: "accounts",
  action: "history",
  sequence: 75,
});
