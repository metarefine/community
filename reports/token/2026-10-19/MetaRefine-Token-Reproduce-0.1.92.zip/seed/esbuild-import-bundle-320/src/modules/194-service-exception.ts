export const record = Object.freeze({
  id: "service.exception",
  label: "Service Exception",
  domain: "service",
  action: "exception",
  sequence: 194,
});
