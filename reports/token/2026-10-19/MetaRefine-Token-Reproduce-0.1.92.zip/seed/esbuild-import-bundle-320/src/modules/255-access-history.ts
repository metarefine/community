export const record = Object.freeze({
  id: "access.history",
  label: "Access History",
  domain: "access",
  action: "history",
  sequence: 255,
});
