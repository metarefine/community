export const record = Object.freeze({
  id: "procurement.intake",
  label: "Procurement Intake",
  domain: "procurement",
  action: "intake",
  sequence: 161,
});
