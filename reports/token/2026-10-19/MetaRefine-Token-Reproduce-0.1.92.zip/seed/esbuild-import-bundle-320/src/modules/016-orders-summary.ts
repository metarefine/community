export const record = Object.freeze({
  id: "orders.summary",
  label: "Orders Summary",
  domain: "orders",
  action: "summary",
  sequence: 16,
});
