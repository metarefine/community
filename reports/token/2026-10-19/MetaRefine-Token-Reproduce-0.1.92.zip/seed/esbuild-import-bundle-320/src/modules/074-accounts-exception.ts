export const record = Object.freeze({
  id: "accounts.exception",
  label: "Accounts Exception",
  domain: "accounts",
  action: "exception",
  sequence: 74,
});
