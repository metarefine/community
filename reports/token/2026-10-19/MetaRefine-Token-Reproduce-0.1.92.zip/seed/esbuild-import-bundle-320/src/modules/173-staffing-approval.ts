export const record = Object.freeze({
  id: "staffing.approval",
  label: "Staffing Approval",
  domain: "staffing",
  action: "approval",
  sequence: 173,
});
