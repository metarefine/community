export const record = Object.freeze({
  id: "shipping.exception",
  label: "Shipping Exception",
  domain: "shipping",
  action: "exception",
  sequence: 134,
});
