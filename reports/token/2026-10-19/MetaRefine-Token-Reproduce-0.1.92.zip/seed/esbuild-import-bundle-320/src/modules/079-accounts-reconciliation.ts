export const record = Object.freeze({
  id: "accounts.reconciliation",
  label: "Accounts Reconciliation",
  domain: "accounts",
  action: "reconciliation",
  sequence: 79,
});
