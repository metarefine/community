export const record = Object.freeze({
  id: "integrations.intake",
  label: "Integrations Intake",
  domain: "integrations",
  action: "intake",
  sequence: 261,
});
