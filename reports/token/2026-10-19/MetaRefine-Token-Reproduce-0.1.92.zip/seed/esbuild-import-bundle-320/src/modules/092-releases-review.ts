export const record = Object.freeze({
  id: "releases.review",
  label: "Releases Review",
  domain: "releases",
  action: "review",
  sequence: 92,
});
