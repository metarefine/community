export const record = Object.freeze({
  id: "support.approval",
  label: "Support Approval",
  domain: "support",
  action: "approval",
  sequence: 53,
});
