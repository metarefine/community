export const record = Object.freeze({
  id: "projects.routing",
  label: "Projects Routing",
  domain: "projects",
  action: "routing",
  sequence: 88,
});
