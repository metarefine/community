export const record = Object.freeze({
  id: "access.approval",
  label: "Access Approval",
  domain: "access",
  action: "approval",
  sequence: 253,
});
