export const record = Object.freeze({
  id: "exports.reconciliation",
  label: "Exports Reconciliation",
  domain: "exports",
  action: "reconciliation",
  sequence: 289,
});
