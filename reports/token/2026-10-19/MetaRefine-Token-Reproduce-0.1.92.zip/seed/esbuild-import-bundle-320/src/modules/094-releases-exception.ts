export const record = Object.freeze({
  id: "releases.exception",
  label: "Releases Exception",
  domain: "releases",
  action: "exception",
  sequence: 94,
});
