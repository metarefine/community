export const record = Object.freeze({
  id: "projects.summary",
  label: "Projects Summary",
  domain: "projects",
  action: "summary",
  sequence: 86,
});
