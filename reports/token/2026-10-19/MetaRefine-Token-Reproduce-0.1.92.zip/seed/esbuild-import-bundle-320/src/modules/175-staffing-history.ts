export const record = Object.freeze({
  id: "staffing.history",
  label: "Staffing History",
  domain: "staffing",
  action: "history",
  sequence: 175,
});
