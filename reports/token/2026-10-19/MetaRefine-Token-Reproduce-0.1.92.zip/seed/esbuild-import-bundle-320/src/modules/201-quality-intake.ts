export const record = Object.freeze({
  id: "quality.intake",
  label: "Quality Intake",
  domain: "quality",
  action: "intake",
  sequence: 201,
});
