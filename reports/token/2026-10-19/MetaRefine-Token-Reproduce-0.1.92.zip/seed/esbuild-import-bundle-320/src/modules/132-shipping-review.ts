export const record = Object.freeze({
  id: "shipping.review",
  label: "Shipping Review",
  domain: "shipping",
  action: "review",
  sequence: 132,
});
