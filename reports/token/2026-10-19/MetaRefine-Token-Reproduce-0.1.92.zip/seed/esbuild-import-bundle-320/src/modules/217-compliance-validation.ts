export const record = Object.freeze({
  id: "compliance.validation",
  label: "Compliance Validation",
  domain: "compliance",
  action: "validation",
  sequence: 217,
});
