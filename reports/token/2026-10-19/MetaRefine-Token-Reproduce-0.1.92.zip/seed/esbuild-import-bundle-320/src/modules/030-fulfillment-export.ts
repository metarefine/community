export const record = Object.freeze({
  id: "fulfillment.export",
  label: "Fulfillment Export",
  domain: "fulfillment",
  action: "export",
  sequence: 30,
});
