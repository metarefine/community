export const record = Object.freeze({
  id: "projects.intake",
  label: "Projects Intake",
  domain: "projects",
  action: "intake",
  sequence: 81,
});
