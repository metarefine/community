export const record = Object.freeze({
  id: "audit.validation",
  label: "Audit Validation",
  domain: "audit",
  action: "validation",
  sequence: 117,
});
