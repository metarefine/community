export const record = Object.freeze({
  id: "billing.history",
  label: "Billing History",
  domain: "billing",
  action: "history",
  sequence: 65,
});
