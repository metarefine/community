export const record = Object.freeze({
  id: "orders.export",
  label: "Orders Export",
  domain: "orders",
  action: "export",
  sequence: 20,
});
