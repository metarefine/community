export const record = Object.freeze({
  id: "notifications.intake",
  label: "Notifications Intake",
  domain: "notifications",
  action: "intake",
  sequence: 151,
});
