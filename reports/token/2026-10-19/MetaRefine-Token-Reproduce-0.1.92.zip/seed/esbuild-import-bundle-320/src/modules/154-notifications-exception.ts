export const record = Object.freeze({
  id: "notifications.exception",
  label: "Notifications Exception",
  domain: "notifications",
  action: "exception",
  sequence: 154,
});
