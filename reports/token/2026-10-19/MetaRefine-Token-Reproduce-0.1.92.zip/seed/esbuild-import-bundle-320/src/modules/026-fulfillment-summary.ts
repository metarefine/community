export const record = Object.freeze({
  id: "fulfillment.summary",
  label: "Fulfillment Summary",
  domain: "fulfillment",
  action: "summary",
  sequence: 26,
});
