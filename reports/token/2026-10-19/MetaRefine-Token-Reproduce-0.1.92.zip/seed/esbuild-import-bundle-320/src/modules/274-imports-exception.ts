export const record = Object.freeze({
  id: "imports.exception",
  label: "Imports Exception",
  domain: "imports",
  action: "exception",
  sequence: 274,
});
