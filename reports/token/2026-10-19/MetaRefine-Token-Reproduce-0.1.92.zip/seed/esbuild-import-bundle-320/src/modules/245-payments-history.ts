export const record = Object.freeze({
  id: "payments.history",
  label: "Payments History",
  domain: "payments",
  action: "history",
  sequence: 245,
});
