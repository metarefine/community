export const record = Object.freeze({
  id: "catalog.exception",
  label: "Catalog Exception",
  domain: "catalog",
  action: "exception",
  sequence: 44,
});
