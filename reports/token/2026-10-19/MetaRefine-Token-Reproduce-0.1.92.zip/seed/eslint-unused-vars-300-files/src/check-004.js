const unusedValue004 = 4;
