const unusedValue124 = 124;
