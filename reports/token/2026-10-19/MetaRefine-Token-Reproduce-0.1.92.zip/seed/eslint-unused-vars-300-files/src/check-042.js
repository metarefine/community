const unusedValue042 = 42;
