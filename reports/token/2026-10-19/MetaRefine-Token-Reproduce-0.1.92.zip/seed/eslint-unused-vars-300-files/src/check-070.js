const unusedValue070 = 70;
