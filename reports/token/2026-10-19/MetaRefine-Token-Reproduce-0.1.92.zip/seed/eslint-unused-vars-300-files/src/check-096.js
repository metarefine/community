const unusedValue096 = 96;
