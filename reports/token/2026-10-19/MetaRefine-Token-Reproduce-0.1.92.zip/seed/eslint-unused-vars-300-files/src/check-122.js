const unusedValue122 = 122;
