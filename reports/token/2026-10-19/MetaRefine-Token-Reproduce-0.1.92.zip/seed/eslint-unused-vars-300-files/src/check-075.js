const unusedValue075 = 75;
