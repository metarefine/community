const unusedValue112 = 112;
