const unusedValue100 = 100;
