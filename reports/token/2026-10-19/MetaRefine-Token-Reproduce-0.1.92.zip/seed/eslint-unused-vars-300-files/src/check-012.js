const unusedValue012 = 12;
