const unusedValue023 = 23;
