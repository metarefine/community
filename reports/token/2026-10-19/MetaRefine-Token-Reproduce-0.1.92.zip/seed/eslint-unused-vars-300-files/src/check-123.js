const unusedValue123 = 123;
