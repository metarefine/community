# WorkBuddy 五案手动复现

先通过 MetaRefine「工具」页接通 WorkBuddy，并固定 `mr-deepseek`（DeepSeek Flash）、方案 `standard` 和同一套工具版本。每个案例的 OFF 与 ON 都从同一份 `seed/<case-id>` 复制到各自全新空白工作区，并各开一个新 WorkBuddy 会话；`context_optimization` 与 `tool_output_reduction` 两项同时关闭或开启。完整提示见 `prompts/<case-id>.txt`，答案预期见 `cases.json`。

客户可以在同一当前 0.1.92 安装中重新跑 OFF 与 ON；表中历史关闭组仍按原始对照标为 0.1.90 或 0.1.91，不要求取得旧候选。保持其他设置、案例内容和工具版本一致。工具版本：Node 24.20.0、npm 11.17、TypeScript 6.0.3、ESLint 10.10.0、esbuild 0.28.2。`synthetic-shell-status-control` 是明确标注的合成控制场景。

在 MetaRefine 本机累计 input/output Token 计数中，记录单个案例运行前后的值并计算差值；测量时暂停其他客户端活动。每个案例/阶段单独计数，完整任务的所有请求都在差值中。也可用 WorkBuddy CLI 的最后一条 `type=result` 中 `usage.input_tokens` 与 `usage.output_tokens` 求和。不要把 cache_read_input_tokens 再加到 input_tokens。

## 可选：按单个案例/阶段读取 CLI usage

先把复现 ZIP 解压到固定目录，记录该解压目录的绝对路径。以下命令以 `orders-regression-green-1800` 的 OFF 组为例；切换为 ON 时使用另一个全新工作区和 `orders-regression-green-1800-on.jsonl` 日志。提示文件与 usage 日志都位于案例工作区之外。若路径已存在，请为本次运行换一个新路径，不要复用旧工作区。

下面的插件目录与 MCP 配置路径必须来自你自己在 MetaRefine「工具」页接通 WorkBuddy 时使用的配置。不要省略这两个参数后把独立 CLI 调用当成等价 Harness；不要分享配置内容或密钥。普通工具授权即可，无需跳过权限确认。

```powershell
# 先记录解压目录绝对路径；不要在进入工作区后再解析相对路径
$packageRoot = (Resolve-Path 'C:\absolute\path\to\MetaRefine-Token-Reproduce-0.1.92').Path
$caseId = 'orders-regression-green-1800'
$phase = 'off' # OFF 与 ON 分别使用全新工作区和会话
$outer = Split-Path $packageRoot -Parent
$workspace = Join-Path $outer "$caseId-$phase-workspace"
$usageDir = Join-Path $outer 'usage'
$usageFile = Join-Path $usageDir "$caseId-$phase.jsonl"
$seedDir = Join-Path $packageRoot "seed\$caseId"
$taskPrompt = Get-Content -LiteralPath (Join-Path $packageRoot "prompts\$caseId.txt") -Raw
$wbCli = Join-Path $env:LOCALAPPDATA 'Programs\WorkBuddy\resources\app.asar.unpacked\cli\dist\codebuddy-lite-wb.mjs'
$mrPluginDir = '填入你自己的 MR WorkBuddy 插件目录'
$mrMcpConfig = '填入你自己的 MR WorkBuddy MCP 配置路径'
if ((Test-Path -LiteralPath $workspace) -or (Test-Path -LiteralPath $usageFile)) { throw 'Choose new workspace and usage log paths for this run' }
New-Item -ItemType Directory -Path $workspace, $usageDir -Force | Out-Null
Copy-Item -Path (Join-Path $seedDir '*') -Destination $workspace -Recurse
$wbArgs = @('-p', '--output-format', 'stream-json', '--plugin-dir', $mrPluginDir, '--mcp-config', $mrMcpConfig, '--model', 'custom-local:mr-deepseek', '--tools', 'default', '--allowedTools=Bash,Read,Write', $taskPrompt)
Push-Location $workspace
try { node $wbCli @wbArgs > $usageFile } finally { Pop-Location }

# 只读这一条案例、这一阶段的日志，不读取混有其他阶段的日志集合
$lastUsage = $null
foreach ($line in Get-Content -LiteralPath $usageFile) {
  $event = $line | ConvertFrom-Json
  if ($event.type -eq 'result') { $lastUsage = $event.usage }
}
if ($null -eq $lastUsage) { throw 'Missing final result usage' }
$inputTokens = [long]$lastUsage.input_tokens
$outputTokens = [long]$lastUsage.output_tokens
"input_tokens=$inputTokens"
"output_tokens=$outputTokens"
"total_tokens=$($inputTokens + $outputTokens)"
```

同一案例的 OFF、ON 分别检查答案，并各自记录本阶段的 usage。复跑会得到新的本机样本；原始 JSONL 可能含本地会话标识，不要分享。
